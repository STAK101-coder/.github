import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://bkcmxnoirlfgnaxzohqr.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJrY214bm9pcmxmZ25heHpvaHFyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzMzQ5NDQsImV4cCI6MjA2MzkxMDk0NH0.pycrizb5ijOjR3B7Bh5T_47nE_hcT6eqOPJ1ny_V_Rw';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };