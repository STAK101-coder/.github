import React from 'react';
import AppLayout from '@/components/AppLayout';
import ShopifyDashboard from '@/components/ShopifyDashboard';
import { Card, CardContent } from '@/components/ui/card';
import { ShoppingBag, Truck, DollarSign, CheckCircle } from 'lucide-react';

const ShopifyPage: React.FC = () => {
  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Shopify <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">Integration</span>
          </h1>
          <p className="text-xl text-gray-600 mb-6">
            Connect your Shopify stores and enable dropshipping with our verified suppliers
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-green-50 to-green-100">
              <CardContent className="p-6 text-center">
                <ShoppingBag className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="font-semibold text-green-800 mb-2">Easy Integration</h3>
                <p className="text-sm text-green-700">Connect your Shopify store in minutes with our simple setup process</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
              <CardContent className="p-6 text-center">
                <Truck className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="font-semibold text-blue-800 mb-2">Automated Dropshipping</h3>
                <p className="text-sm text-blue-700">Suppliers handle fulfillment and shipping directly to your customers</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
              <CardContent className="p-6 text-center">
                <DollarSign className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                <h3 className="font-semibold text-purple-800 mb-2">Earn Commission</h3>
                <p className="text-sm text-purple-700">Get paid for every sale without managing inventory or shipping</p>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <ShopifyDashboard />
        
        <Card className="mt-8 bg-gradient-to-r from-green-600 to-blue-600">
          <CardContent className="p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold mb-2">Ready to Start Dropshipping?</h3>
                <p className="opacity-90">Connect your first Shopify store and start earning commission today!</p>
              </div>
              <CheckCircle className="h-12 w-12 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default ShopifyPage;