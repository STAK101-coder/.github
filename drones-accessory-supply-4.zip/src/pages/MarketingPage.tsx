import MarketingDashboard from "@/components/MarketingDashboard";
import AppLayout from "@/components/AppLayout";

const MarketingPage = () => {
  return (
    <AppLayout>
      <MarketingDashboard />
    </AppLayout>
  );
};

export default MarketingPage;