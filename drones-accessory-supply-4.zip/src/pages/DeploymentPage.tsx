import React from 'react';
import DeploymentSuccessMessage from '../components/DeploymentSuccessMessage';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Rocket, Terminal, ExternalLink } from 'lucide-react';

const DeploymentPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <DeploymentSuccessMessage />
      
      <div className="mt-8 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Build Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span>React Application</span>
                <Badge className="bg-green-100 text-green-800">Ready</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>TypeScript Compilation</span>
                <Badge className="bg-green-100 text-green-800">Ready</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Supabase Integration</span>
                <Badge className="bg-green-100 text-green-800">Ready</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Authentication System</span>
                <Badge className="bg-green-100 text-green-800">Ready</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-800">⚡ Quick Deploy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-yellow-700">
                Your application is ready for production deployment. Choose your preferred platform:
              </p>
              <div className="flex gap-4">
                <Button className="bg-black text-white hover:bg-gray-800" asChild>
                  <a href="https://vercel.com/new" target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Deploy to Vercel
                  </a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="https://app.netlify.com/start" target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Deploy to Netlify
                  </a>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DeploymentPage;