import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SecurityAuditReport from '@/components/SecurityAuditReport';
import SSLSetupWizard from '@/components/SSLSetupWizard';
import RateLimitingSetup from '@/components/RateLimitingSetup';
import SecurityImplementationGuide from '@/components/SecurityImplementationGuide';
import SecurityDashboard from '@/components/SecurityDashboard';

const SecurityPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <Tabs defaultValue="audit" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="audit">Security Audit</TabsTrigger>
          <TabsTrigger value="ssl">SSL Setup</TabsTrigger>
          <TabsTrigger value="ratelimit">Rate Limiting</TabsTrigger>
          <TabsTrigger value="guide">Setup Guide</TabsTrigger>
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
        </TabsList>
        
        <TabsContent value="audit">
          <SecurityAuditReport />
        </TabsContent>
        
        <TabsContent value="ssl">
          <SSLSetupWizard />
        </TabsContent>
        
        <TabsContent value="ratelimit">
          <RateLimitingSetup />
        </TabsContent>
        
        <TabsContent value="guide">
          <SecurityImplementationGuide />
        </TabsContent>
        
        <TabsContent value="dashboard">
          <SecurityDashboard />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SecurityPage;