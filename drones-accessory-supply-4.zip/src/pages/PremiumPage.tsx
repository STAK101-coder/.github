import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AdvancedDashboard from "@/components/AdvancedDashboard";
import AppLayout from "@/components/AppLayout";
import { Crown, Rocket, Shield, Zap, Users, Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Chen",
    role: "E-commerce Entrepreneur",
    content: "DRONE WARS transformed my business. The AI automation saved me 40 hours per week!",
    rating: 5,
    revenue: "$50K/month"
  },
  {
    name: "Marcus Rodriguez",
    role: "Dropshipping Expert",
    content: "The predictive analytics helped me identify winning products before my competitors.",
    rating: 5,
    revenue: "$120K/month"
  },
  {
    name: "Lisa Thompson",
    role: "Business Owner",
    content: "From beginner to 6-figures in 8 months. The AI trainer was like having a mentor 24/7.",
    rating: 5,
    revenue: "$85K/month"
  }
];

const features = [
  {
    title: "Military-Grade Security",
    description: "Bank-level encryption and security protocols",
    icon: Shield
  },
  {
    title: "Lightning Fast Performance",
    description: "99.9% uptime with global CDN infrastructure",
    icon: Zap
  },
  {
    title: "24/7 Elite Support",
    description: "Dedicated account managers and phone support",
    icon: Users
  },
  {
    title: "Instant Deployment",
    description: "Launch your store in under 5 minutes",
    icon: Rocket
  }
];

export default function PremiumPage() {
  const [selectedPlan, setSelectedPlan] = useState("pro");

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-black">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Crown className="w-12 h-12 text-yellow-500" />
              <h1 className="text-5xl font-bold text-white">DRONE WARS</h1>
            </div>
            <h2 className="text-3xl font-bold text-red-500 mb-4">PREMIUM DROPSHIPPING PLATFORM</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              The world's first AI-powered dropshipping platform with military-grade precision.
              Join 12,000+ successful entrepreneurs dominating their markets.
            </p>
          </div>

          <Tabs defaultValue="dashboard" className="space-y-8">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800 border-gray-700">
              <TabsTrigger value="dashboard">Command Center</TabsTrigger>
              <TabsTrigger value="features">Elite Features</TabsTrigger>
              <TabsTrigger value="testimonials">Success Stories</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard">
              <AdvancedDashboard />
            </TabsContent>

            <TabsContent value="features">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {features.map((feature, index) => {
                  const IconComponent = feature.icon;
                  return (
                    <Card key={index} className="bg-gray-800 border-gray-700">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-white">
                          <IconComponent className="w-8 h-8 text-red-500" />
                          {feature.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-300">{feature.description}</p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="testimonials">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.map((testimonial, index) => (
                  <Card key={index} className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-white">{testimonial.name}</CardTitle>
                          <p className="text-gray-400">{testimonial.role}</p>
                        </div>
                        <Badge className="bg-green-600">{testimonial.revenue}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex mb-3">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                        ))}
                      </div>
                      <p className="text-gray-300 italic">"{testimonial.content}"</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="text-center mt-12">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 text-lg">
              <Crown className="w-5 h-5 mr-2" />
              Start Your Empire Today
            </Button>
            <p className="text-gray-400 mt-4">30-day money-back guarantee • No setup fees • Cancel anytime</p>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}