import React from 'react';
import AppLayout from '@/components/AppLayout';
import FinalAnalysis from '@/components/FinalAnalysis';

const AnalysisPage: React.FC = () => {
  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        <FinalAnalysis />
      </div>
    </AppLayout>
  );
};

export default AnalysisPage;