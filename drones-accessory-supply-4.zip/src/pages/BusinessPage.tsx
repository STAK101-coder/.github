import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import BusinessRegistration from '@/components/BusinessRegistration';
import BusinessDirectory from '@/components/BusinessDirectory';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building2, Plus, Users, TrendingUp, Star } from 'lucide-react';

const BusinessPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('directory');

  const stats = [
    {
      title: 'Total Businesses',
      value: '1,247',
      change: '+12%',
      icon: Building2,
      color: 'text-blue-600'
    },
    {
      title: 'Active Campaigns',
      value: '3,891',
      change: '+8%',
      icon: TrendingUp,
      color: 'text-green-600'
    },
    {
      title: 'Success Rate',
      value: '94.2%',
      change: '+2.1%',
      icon: Star,
      color: 'text-yellow-600'
    },
    {
      title: 'New This Month',
      value: '156',
      change: '+24%',
      icon: Plus,
      color: 'text-purple-600'
    }
  ];

  return (
    <AppLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Building2 className="w-8 h-8" />
              All In One Marketing
            </h1>
            <p className="text-gray-600 mt-1">
              Comprehensive marketing platform for businesses of all sizes
            </p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {stat.title}
                  </CardTitle>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-600">{stat.change}</span> from last month
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Platform Features */}
        <Card>
          <CardHeader>
            <CardTitle>Platform Features</CardTitle>
            <CardDescription>
              Everything you need to grow your business online
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              <Badge variant="secondary" className="justify-center py-2">
                Social Media Management
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                Email Marketing
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                SEO Optimization
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                Paid Advertising
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                Analytics & Reporting
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                E-commerce Tools
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                CRM Integration
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                Marketing Automation
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                Content Management
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                Lead Generation
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                A/B Testing
              </Badge>
              <Badge variant="secondary" className="justify-center py-2">
                24/7 Support
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="directory" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Business Directory
            </TabsTrigger>
            <TabsTrigger value="register" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Your Business
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="directory" className="mt-6">
            <BusinessDirectory />
          </TabsContent>
          
          <TabsContent value="register" className="mt-6">
            <BusinessRegistration />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default BusinessPage;