import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import UserAuthSystem from '@/components/UserAuthSystem';
import AppLayout from '@/components/AppLayout';
import HeroSection from '@/components/HeroSection';
import CategorySection from '@/components/CategorySection';
import DroneGrid from '@/components/DroneGrid';
import SupplierSection from '@/components/SupplierSection';
import QuickAccessPanel from '@/components/QuickAccessPanel';
import PricingPlans from '@/components/PricingPlans';
import LiveMarketData from '@/components/LiveMarketData';
import CompetitorAnalysis from '@/components/CompetitorAnalysis';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Crown, Zap, Brain, Target, Shield, Rocket } from 'lucide-react';

const Index: React.FC = () => {
  const { isAuthenticated, login, user } = useAuth();

  if (!isAuthenticated) {
    return <UserAuthSystem onAuthComplete={login} />;
  }

  return (
    <AppLayout>
      <div className="space-y-8">
        {/* Welcome Message */}
        <Card className="bg-gradient-to-r from-green-900 to-blue-900 border-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Shield className="w-12 h-12 text-green-500" />
                <div>
                  <h2 className="text-2xl font-bold text-white">Welcome back, {user?.username}! 🚁</h2>
                  <p className="text-gray-300">Your Drone Wars command center is ready for action</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Premium Features Banner */}
        <Card className="bg-gradient-to-r from-red-900 to-purple-900 border-red-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Crown className="w-12 h-12 text-yellow-500" />
                <div>
                  <h2 className="text-2xl font-bold text-white">World's Most Advanced Dropshipping Platform</h2>
                  <p className="text-gray-300">AI-Powered • Predictive Analytics • Personal Business Coach</p>
                </div>
              </div>
              <Button size="lg" className="bg-yellow-600 hover:bg-yellow-700 text-black font-bold">
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Premium
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="store" className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-gray-800 border-gray-700">
            <TabsTrigger value="store" className="flex items-center gap-2">
              <Rocket className="w-4 h-4" />
              Store Front
            </TabsTrigger>
            <TabsTrigger value="management" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Management
            </TabsTrigger>
            <TabsTrigger value="pricing" className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Pricing Plans
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Live Analytics
            </TabsTrigger>
            <TabsTrigger value="intelligence" className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              Market Intel
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="store" className="space-y-8">
            <HeroSection />
            <CategorySection />
            <DroneGrid />
            <SupplierSection />
          </TabsContent>
          
          <TabsContent value="management">
            <QuickAccessPanel />
          </TabsContent>

          <TabsContent value="pricing">
            <PricingPlans />
          </TabsContent>

          <TabsContent value="analytics">
            <LiveMarketData />
          </TabsContent>

          <TabsContent value="intelligence">
            <CompetitorAnalysis />
          </TabsContent>
        </Tabs>

        {/* Unique Features Section */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-center text-2xl">
              What Makes DRONE WARS Different
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center text-white">
                <Brain className="w-16 h-16 mx-auto mb-4 text-blue-500" />
                <h3 className="text-xl font-bold mb-2">AI Business Coach</h3>
                <p className="text-gray-300">Personal AI trainer guides you from beginner to enterprise level with customized learning paths</p>
              </div>
              <div className="text-center text-white">
                <Zap className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
                <h3 className="text-xl font-bold mb-2">Predictive Automation</h3>
                <p className="text-gray-300">AI predicts market trends and automates pricing, inventory, and marketing before competitors react</p>
              </div>
              <div className="text-center text-white">
                <Target className="w-16 h-16 mx-auto mb-4 text-red-500" />
                <h3 className="text-xl font-bold mb-2">Military Precision</h3>
                <p className="text-gray-300">Combat-tested strategies and tactical approaches to dominate your market with surgical precision</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default Index;