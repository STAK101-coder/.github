import React from 'react';
import AppLayout from '@/components/AppLayout';
import OwnerDashboard from '@/components/OwnerDashboard';

const OwnerPage: React.FC = () => {
  return (
    <AppLayout>
      <OwnerDashboard />
    </AppLayout>
  );
};

export default OwnerPage;