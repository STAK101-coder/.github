import React from 'react';
import AppLayout from '@/components/AppLayout';
import AIDashboard from '@/components/AIDashboard';

const AIPage = () => {
  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">AI Assistant</h1>
          <p className="text-muted-foreground">
            Automated business management powered by artificial intelligence
          </p>
        </div>
        <AIDashboard />
      </div>
    </AppLayout>
  );
};

export default AIPage;