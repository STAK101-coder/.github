import React from 'react';
import SupplierSection from '@/components/SupplierSection';

const SuppliersAffiliatePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <SupplierSection />
    </div>
  );
};

export default SuppliersAffiliatePage;