import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { AppContextProvider } from "@/contexts/AppContext";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ShopifyPage from "./pages/ShopifyPage";
import AdminPage from "./pages/AdminPage";
import MarketingPage from "./pages/MarketingPage";
import OwnerPage from "./pages/OwnerPage";
import AIPage from "./pages/AIPage";
import SecurityPage from "./pages/SecurityPage";
import SuppliersAffiliatePage from "./pages/SuppliersAffiliatePage";
import AnalysisPage from "./pages/AnalysisPage";
import DeploymentPage from "./pages/DeploymentPage";
import BusinessPage from "./pages/BusinessPage";
import PremiumPage from "./pages/PremiumPage";
import InventoryPage from "./components/InventoryPage";
import CheckoutPage from "./components/CheckoutPage";

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider defaultTheme="light">
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppContextProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/owner" element={<OwnerPage />} />
                <Route path="/ai" element={<AIPage />} />
                <Route path="/security" element={<SecurityPage />} />
                <Route path="/suppliers" element={<SuppliersAffiliatePage />} />
                <Route path="/analysis" element={<AnalysisPage />} />
                <Route path="/deploy" element={<DeploymentPage />} />
                <Route path="/business" element={<BusinessPage />} />
                <Route path="/premium" element={<PremiumPage />} />
                <Route path="/inventory" element={<InventoryPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/shopify" element={<ShopifyPage />} />
                <Route path="/marketing" element={<MarketingPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </AppContextProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;