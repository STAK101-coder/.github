import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Shield, Database, Eye, Download, Trash2, Lock, UserCheck } from 'lucide-react';

const DataProtection: React.FC = () => {
  const [privacySettings, setPrivacySettings] = useState({
    dataCollection: true,
    analytics: true,
    marketing: false,
    thirdParty: false
  });

  const dataCategories = [
    {
      category: 'Personal Information',
      description: 'Name, email, phone number, address',
      encrypted: true,
      retention: '7 years',
      purpose: 'Order processing and customer service'
    },
    {
      category: 'Payment Data',
      description: 'Credit card info (tokenized), billing address',
      encrypted: true,
      retention: '3 years',
      purpose: 'Transaction processing'
    },
    {
      category: 'Usage Analytics',
      description: 'Page views, clicks, session data',
      encrypted: true,
      retention: '2 years',
      purpose: 'Service improvement'
    },
    {
      category: 'Device Information',
      description: 'IP address, browser type, device ID',
      encrypted: true,
      retention: '1 year',
      purpose: 'Security and fraud prevention'
    }
  ];

  const complianceStandards = [
    { name: 'GDPR', status: 'Compliant', description: 'European data protection regulation' },
    { name: 'CCPA', status: 'Compliant', description: 'California consumer privacy act' },
    { name: 'PCI DSS', status: 'Certified', description: 'Payment card industry security' },
    { name: 'SOC 2', status: 'Certified', description: 'Security and availability controls' }
  ];

  const handlePrivacyToggle = (setting: string) => {
    setPrivacySettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev]
    }));
  };

  const handleDataRequest = (type: 'export' | 'delete') => {
    // Simulate data request processing
    alert(`${type === 'export' ? 'Data export' : 'Data deletion'} request submitted. You will receive confirmation within 30 days.`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="h-6 w-6" />
          Data Protection & Privacy
        </h2>
        <Badge variant="outline" className="text-green-600 border-green-600">
          GDPR Compliant
        </Badge>
      </div>

      {/* Privacy Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Privacy Controls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dataCollection">Essential Data Collection</Label>
                <p className="text-sm text-gray-600">Required for core functionality</p>
              </div>
              <Switch
                id="dataCollection"
                checked={privacySettings.dataCollection}
                onCheckedChange={() => handlePrivacyToggle('dataCollection')}
                disabled
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="analytics">Analytics & Performance</Label>
                <p className="text-sm text-gray-600">Help us improve our services</p>
              </div>
              <Switch
                id="analytics"
                checked={privacySettings.analytics}
                onCheckedChange={() => handlePrivacyToggle('analytics')}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="marketing">Marketing Communications</Label>
                <p className="text-sm text-gray-600">Promotional emails and offers</p>
              </div>
              <Switch
                id="marketing"
                checked={privacySettings.marketing}
                onCheckedChange={() => handlePrivacyToggle('marketing')}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="thirdParty">Third-party Sharing</Label>
                <p className="text-sm text-gray-600">Share data with partners</p>
              </div>
              <Switch
                id="thirdParty"
                checked={privacySettings.thirdParty}
                onCheckedChange={() => handlePrivacyToggle('thirdParty')}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Data We Collect
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dataCategories.map((item, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold">{item.category}</h4>
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-green-600" />
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      Encrypted
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Retention: </span>
                    <span>{item.retention}</span>
                  </div>
                  <div>
                    <span className="font-medium">Purpose: </span>
                    <span>{item.purpose}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Compliance Standards */}
      <Card>
        <CardHeader>
          <CardTitle>Compliance & Certifications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {complianceStandards.map((standard, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-semibold">{standard.name}</h4>
                  <p className="text-sm text-gray-600">{standard.description}</p>
                </div>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  {standard.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Data Rights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Your Data Rights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              You have the right to access, correct, or delete your personal data. 
              Use the buttons below to exercise these rights.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                onClick={() => handleDataRequest('export')}
                className="h-16 flex-col gap-2"
              >
                <Download className="h-5 w-5" />
                <span>Export My Data</span>
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => handleDataRequest('delete')}
                className="h-16 flex-col gap-2 text-red-600 border-red-600 hover:bg-red-50"
              >
                <Trash2 className="h-5 w-5" />
                <span>Delete My Data</span>
              </Button>
            </div>
            
            <div className="text-xs text-gray-500 mt-4">
              <p>• Data export requests are processed within 30 days</p>
              <p>• Data deletion is permanent and cannot be undone</p>
              <p>• Some data may be retained for legal compliance</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DataProtection;