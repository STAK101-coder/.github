import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Zap, AlertTriangle, CheckCircle, Clock, ExternalLink } from 'lucide-react';

const SecurityAuditReport: React.FC = () => {
  const [auditRunning, setAuditRunning] = useState(false);
  const [lastAudit, setLastAudit] = useState('Never');
  
  const securityScore = 75;
  
  const securityChecks = [
    {
      category: 'SSL/TLS Security',
      items: [
        { name: 'SSL Certificate', status: 'fail', priority: 'high', description: 'SSL certificate not installed' },
        { name: 'HTTPS Redirect', status: 'fail', priority: 'high', description: 'HTTP traffic not redirected to HTTPS' },
        { name: 'TLS Version', status: 'pass', priority: 'medium', description: 'Using TLS 1.2+' },
        { name: 'Certificate Chain', status: 'pending', priority: 'medium', description: 'Awaiting SSL setup' }
      ]
    },
    {
      category: 'Rate Limiting & DDoS',
      items: [
        { name: 'API Rate Limiting', status: 'fail', priority: 'high', description: 'No rate limiting configured' },
        { name: 'DDoS Protection', status: 'fail', priority: 'high', description: 'No DDoS protection active' },
        { name: 'IP Blocking', status: 'pending', priority: 'medium', description: 'Requires Cloudflare setup' },
        { name: 'Bot Protection', status: 'pending', priority: 'low', description: 'Requires Cloudflare setup' }
      ]
    },
    {
      category: 'Application Security',
      items: [
        { name: 'Authentication', status: 'pass', priority: 'high', description: 'Supabase auth implemented' },
        { name: 'Database Security', status: 'pass', priority: 'high', description: 'RLS policies active' },
        { name: 'API Security', status: 'pass', priority: 'medium', description: 'Supabase API keys secured' },
        { name: 'CORS Configuration', status: 'pass', priority: 'medium', description: 'Properly configured' }
      ]
    }
  ];
  
  const runSecurityAudit = () => {
    setAuditRunning(true);
    setTimeout(() => {
      setAuditRunning(false);
      setLastAudit('Just now');
    }, 3000);
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass': return 'text-green-600 border-green-600';
      case 'fail': return 'text-red-600 border-red-600';
      case 'pending': return 'text-yellow-600 border-yellow-600';
      default: return 'text-gray-600 border-gray-600';
    }
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass': return <CheckCircle className="h-4 w-4" />;
      case 'fail': return <AlertTriangle className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      default: return <Shield className="h-4 w-4" />;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="h-6 w-6" />
          Security Audit Report
        </h2>
        <Button onClick={runSecurityAudit} disabled={auditRunning}>
          {auditRunning ? 'Running Audit...' : 'Run Security Audit'}
        </Button>
      </div>
      
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Security Score: {securityScore}% - SSL certificate and rate limiting required for production deployment.
        </AlertDescription>
      </Alert>
      
      <Card>
        <CardHeader>
          <CardTitle>Overall Security Score</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold">{securityScore}%</span>
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                Needs Improvement
              </Badge>
            </div>
            <Progress value={securityScore} className="h-3" />
            <p className="text-sm text-gray-600">Last audit: {lastAudit}</p>
          </div>
        </CardContent>
      </Card>
      
      {securityChecks.map((category, idx) => (
        <Card key={idx}>
          <CardHeader>
            <CardTitle>{category.category}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {category.items.map((item, itemIdx) => (
                <div key={itemIdx} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className={getStatusColor(item.status)}>
                    {getStatusIcon(item.status)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-medium">{item.name}</h4>
                      <Badge variant="outline" className={getStatusColor(item.status)}>
                        {item.status.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{item.description}</p>
                    <Badge variant="outline" className="text-xs mt-1">
                      {item.priority.toUpperCase()} PRIORITY
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
      
      <Card>
        <CardHeader>
          <CardTitle>Recommended Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 border-l-4 border-red-500 bg-red-50">
              <h4 className="font-semibold text-red-800">Critical (Fix Immediately)</h4>
              <ul className="text-sm text-red-700 mt-2 space-y-1">
                <li>• Install SSL certificate via hosting platform</li>
                <li>• Set up Cloudflare for DDoS protection</li>
                <li>• Configure API rate limiting</li>
              </ul>
            </div>
            
            <div className="p-4 border-l-4 border-yellow-500 bg-yellow-50">
              <h4 className="font-semibold text-yellow-800">Medium Priority</h4>
              <ul className="text-sm text-yellow-700 mt-2 space-y-1">
                <li>• Configure IP blocking rules</li>
                <li>• Set up certificate monitoring</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityAuditReport;