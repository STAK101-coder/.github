import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Crown, Building } from "lucide-react";

const plans = [
  {
    name: "Beginner",
    price: "$29",
    period: "/month",
    description: "Perfect for starting your dropshipping journey",
    icon: Star,
    features: [
      "Up to 100 products",
      "Basic AI assistant",
      "Email support",
      "Beginner tutorials",
      "Basic analytics",
      "Standard templates"
    ],
    popular: false,
    color: "bg-blue-500"
  },
  {
    name: "Pro",
    price: "$79",
    period: "/month",
    description: "Advanced tools for growing businesses",
    icon: Zap,
    features: [
      "Up to 1,000 products",
      "Advanced AI automation",
      "Priority support",
      "Pro marketing tools",
      "Advanced analytics",
      "Custom branding",
      "Supplier network access"
    ],
    popular: true,
    color: "bg-purple-500"
  },
  {
    name: "Small Company",
    price: "$199",
    period: "/month",
    description: "Scale your business with enterprise features",
    icon: Building,
    features: [
      "Up to 10,000 products",
      "Full AI automation suite",
      "Dedicated account manager",
      "Multi-store management",
      "Advanced integrations",
      "Team collaboration",
      "Custom workflows"
    ],
    popular: false,
    color: "bg-green-500"
  },
  {
    name: "Enterprise",
    price: "$499",
    period: "/month",
    description: "Complete solution for large operations",
    icon: Crown,
    features: [
      "Unlimited products",
      "White-label solution",
      "24/7 phone support",
      "Custom development",
      "API access",
      "Advanced security",
      "Personal consultant",
      "Training programs"
    ],
    popular: false,
    color: "bg-red-500"
  }
];

export default function PricingPlans() {
  return (
    <div className="py-16 bg-gradient-to-br from-gray-900 to-red-900">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Choose Your Battle Plan</h2>
          <p className="text-gray-300 text-lg">Select the perfect package to dominate your market</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan) => {
            const IconComponent = plan.icon;
            return (
              <Card key={plan.name} className={`relative border-2 ${plan.popular ? 'border-red-500 scale-105' : 'border-gray-700'} bg-gray-800 text-white`}>
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-red-500 text-white">
                    Most Popular
                  </Badge>
                )}
                
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${plan.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription className="text-gray-300">{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-gray-400">{plan.period}</span>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full ${plan.popular ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-700 hover:bg-gray-600'}`}
                    size="lg"
                  >
                    Start Mission
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}