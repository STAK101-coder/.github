import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, ShoppingCart, Target, Shield } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import type { Product } from '@/contexts/AppContext';

interface DroneCardProps {
  product: Product;
}

const DroneCard: React.FC<DroneCardProps> = ({ product }) => {
  const { setSelectedProduct } = useAppContext();
  const {
    name,
    price,
    originalPrice,
    rating,
    reviews,
    image,
    category,
    features,
    inStock,
    images
  } = product;
  
  const discount = originalPrice ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;

  const handleCardClick = () => {
    setSelectedProduct(product);
  };

  return (
    <Card className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border border-red-800 bg-black hover:scale-105 overflow-hidden" onClick={handleCardClick}>
      <div className="relative overflow-hidden">
        {images && images.length > 0 ? (
          <div className="aspect-square overflow-hidden">
            <img
              src={images[0]}
              alt={name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
          </div>
        ) : (
          <div className="aspect-square bg-gradient-to-br from-red-900 to-black flex items-center justify-center text-6xl">
            {image}
          </div>
        )}
        {discount > 0 && (
          <Badge className="absolute top-3 left-3 bg-red-600 hover:bg-red-700 text-white">
            -{discount}%
          </Badge>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-3 right-3 bg-red-900/80 hover:bg-red-800 text-red-400 hover:text-red-300"
          onClick={(e) => e.stopPropagation()}
        >
          <Heart className="h-4 w-4" />
        </Button>
        {!inStock && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
            <Badge variant="secondary" className="text-red-400 bg-red-900 border border-red-700">
              <Shield className="h-3 w-3 mr-1" />
              OFFLINE
            </Badge>
          </div>
        )}
        <Badge className="absolute bottom-3 left-3 bg-red-800 text-white border border-red-600">
          <Target className="h-3 w-3 mr-1" />
          TACTICAL
        </Badge>
      </div>
      
      <CardContent className="p-4 bg-gradient-to-br from-black to-red-900">
        <Badge variant="outline" className="mb-2 text-xs border-red-600 text-red-400">
          {category}
        </Badge>
        <h3 className="font-bold text-lg text-white mb-2 line-clamp-2">{name}</h3>
        
        <div className="flex items-center mb-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-orange-400 fill-current' : 'text-red-800'}`}
              />
            ))}
          </div>
          <span className="text-sm text-red-300 ml-2">({reviews})</span>
        </div>
        
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-2xl font-bold text-red-400">${price}</span>
            {originalPrice && (
              <span className="text-sm text-red-600 line-through ml-2">${originalPrice}</span>
            )}
          </div>
        </div>
        
        <div className="mb-3">
          {features.slice(0, 2).map((feature, index) => (
            <div key={index} className="text-xs text-red-200 mb-1">• {feature}</div>
          ))}
        </div>
        
        <Button 
          className="w-full bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white"
          disabled={!inStock}
          onClick={(e) => e.stopPropagation()}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {inStock ? 'Deploy' : 'On Standby'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default DroneCard;