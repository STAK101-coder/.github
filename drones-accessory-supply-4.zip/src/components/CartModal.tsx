import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PaymentModal from './PaymentModal';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartModal: React.FC<CartModalProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const [cartItems] = useState<CartItem[]>([
    {
      id: '1',
      name: 'DJI Mini 3 Pro',
      price: 759,
      quantity: 1,
      image: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=100&h=100&fit=crop'
    }
  ]);
  const [showPayment, setShowPayment] = useState(false);

  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleCheckout = () => {
    onClose();
    navigate('/checkout');
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              Shopping Cart ({cartItems.length})
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-3">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center gap-3 p-3 border rounded-lg">
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-12 h-12 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{item.name}</h4>
                    <p className="text-blue-600 font-semibold">${item.price}</p>
                  </div>
                  <span className="text-center">Qty: {item.quantity}</span>
                </div>
              ))}
            </div>
            
            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold">Total:</span>
                <span className="text-2xl font-bold text-blue-600">${total}</span>
              </div>
              
              <div className="space-y-2">
                <Button 
                  onClick={() => setShowPayment(true)}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  Quick Pay
                </Button>
                <Button 
                  onClick={handleCheckout}
                  variant="outline"
                  className="w-full"
                >
                  Full Checkout
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      <PaymentModal 
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        product={cartItems.length > 0 ? { name: `${cartItems.length} item(s)`, price: total } : null}
      />
    </>
  );
};

export default CartModal;