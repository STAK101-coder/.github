import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, Eye, AlertTriangle, CheckCircle } from 'lucide-react';

interface SecurityCheck {
  name: string;
  status: 'secure' | 'warning' | 'vulnerable';
  description: string;
  recommendation?: string;
}

const SecurityAudit: React.FC = () => {
  const securityChecks: SecurityCheck[] = [
    {
      name: 'Authentication System',
      status: 'secure',
      description: 'Supabase Auth with JWT tokens',
      recommendation: 'Enable MFA for admin accounts'
    },
    {
      name: 'Database Security',
      status: 'secure',
      description: 'Row Level Security (RLS) enabled',
      recommendation: 'Regular security audits'
    },
    {
      name: 'API Keys Protection',
      status: 'warning',
      description: 'Keys visible in client code',
      recommendation: 'Move sensitive keys to server-side'
    },
    {
      name: 'HTTPS/SSL',
      status: 'warning',
      description: 'Required for production',
      recommendation: 'Configure SSL certificate before launch'
    },
    {
      name: 'Input Validation',
      status: 'secure',
      description: 'Form validation with Zod schemas',
      recommendation: 'Add server-side validation'
    },
    {
      name: 'CORS Configuration',
      status: 'secure',
      description: 'Proper CORS headers in functions',
      recommendation: 'Restrict origins in production'
    },
    {
      name: 'Rate Limiting',
      status: 'warning',
      description: 'Not implemented',
      recommendation: 'Add rate limiting to prevent abuse'
    },
    {
      name: 'Data Encryption',
      status: 'secure',
      description: 'Supabase handles encryption at rest',
      recommendation: 'Encrypt sensitive user data'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'secure': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'vulnerable': return <Shield className="h-5 w-5 text-red-500" />;
      default: return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      secure: 'bg-green-100 text-green-800',
      warning: 'bg-yellow-100 text-yellow-800',
      vulnerable: 'bg-red-100 text-red-800'
    };
    return <Badge className={variants[status as keyof typeof variants]}>{status.toUpperCase()}</Badge>;
  };

  const secureCount = securityChecks.filter(check => check.status === 'secure').length;
  const warningCount = securityChecks.filter(check => check.status === 'warning').length;
  const vulnerableCount = securityChecks.filter(check => check.status === 'vulnerable').length;

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold flex items-center justify-center space-x-2">
          <Shield className="h-6 w-6" />
          <span>Security Audit Report</span>
        </h2>
        <div className="flex justify-center space-x-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{secureCount}</div>
            <div className="text-sm text-gray-600">Secure</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{warningCount}</div>
            <div className="text-sm text-gray-600">Warnings</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{vulnerableCount}</div>
            <div className="text-sm text-gray-600">Vulnerable</div>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Security Checklist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {securityChecks.map((check, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(check.status)}
                    <h3 className="font-medium">{check.name}</h3>
                  </div>
                  {getStatusBadge(check.status)}
                </div>
                <p className="text-sm text-gray-600 mb-2">{check.description}</p>
                {check.recommendation && (
                  <p className="text-sm text-blue-600 bg-blue-50 p-2 rounded">
                    💡 {check.recommendation}
                  </p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityAudit;