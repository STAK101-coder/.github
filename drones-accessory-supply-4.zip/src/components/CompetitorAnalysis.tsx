import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Eye, Target, AlertTriangle, CheckCircle, TrendingUp, Users } from "lucide-react";

const competitors = [
  {
    name: "DroneHub Pro",
    marketShare: 23,
    avgPrice: "$1,450",
    rating: 4.2,
    weaknesses: ["Slow shipping", "Limited support"],
    opportunities: ["Price advantage", "Better customer service"]
  },
  {
    name: "TacticalSupply",
    marketShare: 18,
    avgPrice: "$1,200",
    rating: 3.8,
    weaknesses: ["Poor website", "Limited inventory"],
    opportunities: ["Superior platform", "Better selection"]
  },
  {
    name: "MilitaryGear Direct",
    marketShare: 15,
    avgPrice: "$1,680",
    rating: 4.5,
    weaknesses: ["High prices", "Complex checkout"],
    opportunities: ["Competitive pricing", "Easier ordering"]
  }
];

const insights = [
  {
    type: "opportunity",
    title: "Price Gap Identified",
    description: "Competitors pricing 15-20% higher on tactical drones",
    action: "Increase margins while staying competitive",
    impact: "High"
  },
  {
    type: "threat",
    title: "New Competitor Entry",
    description: "TechDrone Solutions launched with aggressive pricing",
    action: "Monitor pricing and adjust strategy",
    impact: "Medium"
  },
  {
    type: "opportunity",
    title: "Market Gap Found",
    description: "No competitor offers AI-powered recommendations",
    action: "Leverage our AI advantage in marketing",
    impact: "High"
  }
];

export default function CompetitorAnalysis() {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-orange-900 to-red-900 text-white border-orange-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-6 h-6" />
            Competitor Intelligence
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Market Analysis</h3>
              <div className="space-y-4">
                {competitors.map((comp, index) => (
                  <div key={index} className="bg-white/10 p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{comp.name}</span>
                      <Badge variant="outline" className="text-white border-white">
                        {comp.marketShare}% share
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div>
                        <div className="text-sm text-gray-300">Avg Price</div>
                        <div className="font-semibold">{comp.avgPrice}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-300">Rating</div>
                        <div className="font-semibold">{comp.rating}/5.0</div>
                      </div>
                    </div>
                    <Progress value={comp.marketShare * 3} className="mb-2" />
                    <div className="text-sm">
                      <div className="text-red-300 mb-1">Weaknesses: {comp.weaknesses.join(", ")}</div>
                      <div className="text-green-300">Our advantage: {comp.opportunities.join(", ")}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Strategic Insights</h3>
              <div className="space-y-4">
                {insights.map((insight, index) => (
                  <div key={index} className="bg-white/10 p-4 rounded-lg">
                    <div className="flex items-start gap-3">
                      {insight.type === 'opportunity' ? (
                        <CheckCircle className="w-5 h-5 text-green-400 mt-1" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-yellow-400 mt-1" />
                      )}
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{insight.title}</span>
                          <Badge variant={insight.impact === 'High' ? 'destructive' : 'secondary'}>
                            {insight.impact}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-300 mb-2">{insight.description}</p>
                        <div className="text-sm text-blue-400">
                          Action: {insight.action}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 bg-white/10 p-4 rounded-lg">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Competitive Advantage Score
                </h4>
                <div className="text-3xl font-bold text-green-400 mb-2">9.2/10</div>
                <Progress value={92} className="mb-2" />
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-gray-300">Technology Edge</div>
                    <div className="font-semibold text-green-400">Superior</div>
                  </div>
                  <div>
                    <div className="text-gray-300">Market Position</div>
                    <div className="font-semibold text-blue-400">Strong</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}