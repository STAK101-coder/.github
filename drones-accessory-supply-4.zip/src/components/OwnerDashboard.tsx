import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Activity, Shield, Users, DollarSign, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import PerformanceMetrics from './PerformanceMetrics';
import OwnerAuthGuard from './OwnerAuthGuard';
import OwnerAIAssistant from './OwnerAIAssistant';

interface DashboardData {
  totalRevenue: number;
  totalOrders: number;
  totalProducts: number;
  totalSuppliers: number;
  monthlyRevenue: number;
  weeklyOrders: number;
  conversionRate: number;
  avgOrderValue: number;
  topProducts: any[];
  recentActivity: any[];
  trafficSources: any[];
  totalUsers: number;
  activeAffiliates: number;
}

const OwnerDashboard: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [data, setData] = useState<DashboardData>({
    totalRevenue: 156780,
    totalOrders: 1247,
    totalProducts: 89,
    totalSuppliers: 23,
    monthlyRevenue: 45600,
    weeklyOrders: 156,
    conversionRate: 2.5,
    avgOrderValue: 125.50,
    topProducts: [],
    recentActivity: [],
    trafficSources: [
      { source: 'Organic Search', visitors: 1250, percentage: 45 },
      { source: 'Social Media', visitors: 890, percentage: 32 },
      { source: 'Direct', visitors: 420, percentage: 15 },
      { source: 'Paid Ads', visitors: 220, percentage: 8 }
    ],
    totalUsers: 1247,
    activeAffiliates: 89
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const isOwnerAuth = sessionStorage.getItem('owner_authenticated');
    if (isOwnerAuth === 'true') {
      setIsAuthenticated(true);
      fetchDashboardData();
    } else {
      setLoading(false);
    }
  }, []);

  const handleAuthenticated = () => {
    setIsAuthenticated(true);
    fetchDashboardData();
  };

  const fetchDashboardData = async () => {
    try {
      const { data: products } = await supabase.from('inventory').select('*');
      const { data: suppliers } = await supabase.from('suppliers').select('*');
      const { data: users } = await supabase.from('customers').select('*');
      const { data: affiliates } = await supabase.from('affiliate_users').select('*');
      
      setData(prev => ({
        ...prev,
        totalProducts: products?.length || 89,
        totalSuppliers: suppliers?.length || 23,
        totalUsers: users?.length || 1247,
        activeAffiliates: affiliates?.length || 89
      }));
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated) {
    return <OwnerAuthGuard onAuthenticated={handleAuthenticated} />;
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Loading owner dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="border-b bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Shield className="h-8 w-8 text-red-400" />
                OWNER COMMAND CENTER
              </h1>
              <p className="text-slate-300 mt-1">Drone Wars Dropshipping - Master Control</p>
            </div>
            <Badge variant="destructive" className="text-lg px-4 py-2">
              CLASSIFIED ACCESS
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="ai-assistant">AI Assistant</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="border-green-200 bg-green-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-700">Total Revenue</p>
                      <p className="text-2xl font-bold text-green-900">${data.totalRevenue.toLocaleString()}</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-700">Total Users</p>
                      <p className="text-2xl font-bold text-blue-900">{data.totalUsers}</p>
                    </div>
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-purple-200 bg-purple-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-700">Active Affiliates</p>
                      <p className="text-2xl font-bold text-purple-900">{data.activeAffiliates}</p>
                    </div>
                    <Activity className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-700">Monthly Revenue</p>
                      <p className="text-2xl font-bold text-orange-900">${data.monthlyRevenue.toLocaleString()}</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <PerformanceMetrics data={data} />
          </TabsContent>

          <TabsContent value="ai-assistant" className="space-y-6">
            <OwnerAIAssistant />
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <PerformanceMetrics data={data} />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.trafficSources.map((source, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <p className="font-medium">{source.source}</p>
                        <p className="text-sm text-gray-500">{source.visitors} visitors</p>
                      </div>
                      <Badge variant="outline">{source.percentage}%</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default OwnerDashboard;