import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, TrendingUp, Eye, Target, Zap } from 'lucide-react';

interface Alert {
  id: string;
  type: 'warning' | 'success' | 'info';
  title: string;
  message: string;
  action?: string;
}

interface Opportunity {
  id: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  effort: 'high' | 'medium' | 'low';
}

const BusinessInsights: React.FC = () => {
  const alerts: Alert[] = [
    {
      id: '1',
      type: 'warning',
      title: 'Low Inventory Alert',
      message: '5 products are running low on stock',
      action: 'Restock Now'
    },
    {
      id: '2',
      type: 'success',
      title: 'Sales Milestone',
      message: 'Congratulations! You\'ve reached $10K in monthly sales',
    },
    {
      id: '3',
      type: 'info',
      title: 'Marketing Opportunity',
      message: 'Social media engagement is up 25% this week',
    }
  ];

  const opportunities: Opportunity[] = [
    {
      id: '1',
      title: 'Expand Product Line',
      description: 'Add camera accessories to increase average order value',
      impact: 'high',
      effort: 'medium'
    },
    {
      id: '2',
      title: 'Optimize Pricing',
      description: 'Adjust pricing on underperforming products',
      impact: 'medium',
      effort: 'low'
    },
    {
      id: '3',
      title: 'Improve SEO',
      description: 'Optimize product descriptions for better search ranking',
      impact: 'high',
      effort: 'high'
    }
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Eye className="h-4 w-4 text-blue-500" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-green-100 text-green-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Business Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Business Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert.id} className="flex items-start justify-between p-3 border rounded-lg">
                <div className="flex items-start gap-3">
                  {getAlertIcon(alert.type)}
                  <div>
                    <h4 className="font-medium">{alert.title}</h4>
                    <p className="text-sm text-muted-foreground">{alert.message}</p>
                  </div>
                </div>
                {alert.action && (
                  <Button size="sm" variant="outline">
                    {alert.action}
                  </Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Growth Opportunities */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Growth Opportunities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {opportunities.map((opportunity) => (
              <div key={opportunity.id} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium">{opportunity.title}</h4>
                  <div className="flex gap-2">
                    <Badge className={getImpactColor(opportunity.impact)}>
                      {opportunity.impact} impact
                    </Badge>
                    <Badge variant="outline">
                      {opportunity.effort} effort
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{opportunity.description}</p>
                <Button size="sm" className="w-full">
                  <Zap className="h-4 w-4 mr-2" />
                  Implement
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <TrendingUp className="h-6 w-6" />
              <span className="text-sm">View Analytics</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Eye className="h-6 w-6" />
              <span className="text-sm">Check Inventory</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Target className="h-6 w-6" />
              <span className="text-sm">Set Goals</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Zap className="h-6 w-6" />
              <span className="text-sm">Optimize</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BusinessInsights;