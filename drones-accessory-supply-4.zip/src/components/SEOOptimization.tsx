import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Search, TrendingUp, CheckCircle, AlertCircle } from "lucide-react";

const SEOOptimization = () => {
  const seoMetrics = [
    { metric: "Page Speed", score: 85, status: "good" },
    { metric: "Mobile Friendly", score: 92, status: "excellent" },
    { metric: "Meta Tags", score: 78, status: "good" },
    { metric: "Content Quality", score: 88, status: "excellent" },
    { metric: "Backlinks", score: 65, status: "needs-work" },
    { metric: "Schema Markup", score: 45, status: "poor" }
  ];

  const keywordOpportunities = [
    { keyword: "drone dropshipping", volume: 1200, difficulty: "Medium", ranking: 15 },
    { keyword: "buy drones online", volume: 2800, difficulty: "High", ranking: 25 },
    { keyword: "professional drones", volume: 1800, difficulty: "Medium", ranking: 12 },
    { keyword: "drone accessories", volume: 950, difficulty: "Low", ranking: 8 },
    { keyword: "camera drones", volume: 3200, difficulty: "High", ranking: 22 }
  ];

  const contentIdeas = [
    "Best Drones for Photography in 2024",
    "Drone Flying Tips for Beginners",
    "Commercial Drone Applications",
    "Drone Maintenance Guide",
    "Drone Laws and Regulations",
    "Racing Drones vs Camera Drones"
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "excellent": return "bg-green-500";
      case "good": return "bg-blue-500";
      case "needs-work": return "bg-yellow-500";
      case "poor": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">SEO Optimization</h2>
        <Button className="bg-green-600 hover:bg-green-700">
          <Search className="mr-2 h-4 w-4" />
          Run SEO Audit
        </Button>
      </div>

      {/* SEO Score Overview */}
      <Card>
        <CardHeader>
          <CardTitle>SEO Health Score</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            {seoMetrics.map((metric, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{metric.metric}</span>
                  <Badge className={getStatusColor(metric.status)}>
                    {metric.score}%
                  </Badge>
                </div>
                <Progress value={metric.score} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Keyword Opportunities */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Keyword Opportunities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {keywordOpportunities.map((keyword, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">{keyword.keyword}</div>
                    <div className="text-sm text-gray-600">
                      {keyword.volume} searches/month • Rank #{keyword.ranking}
                    </div>
                  </div>
                  <Badge variant={keyword.difficulty === 'Low' ? 'default' : 'secondary'}>
                    {keyword.difficulty}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Content Ideas */}
        <Card>
          <CardHeader>
            <CardTitle>Content Ideas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {contentIdeas.map((idea, index) => (
                <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="flex-1">{idea}</span>
                  <Button variant="outline" size="sm">
                    Create
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick SEO Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto p-4 flex flex-col gap-2">
              <Search className="h-6 w-6" />
              <span>Keyword Research</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col gap-2">
              <TrendingUp className="h-6 w-6" />
              <span>Competitor Analysis</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col gap-2">
              <CheckCircle className="h-6 w-6" />
              <span>Technical SEO</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col gap-2">
              <AlertCircle className="h-6 w-6" />
              <span>Site Audit</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SEOOptimization;