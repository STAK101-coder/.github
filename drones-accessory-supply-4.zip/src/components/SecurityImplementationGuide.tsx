import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Zap, CheckCircle, ExternalLink, AlertTriangle } from 'lucide-react';
import SecuritySetupInstructions from './SecuritySetupInstructions';

const SecurityImplementationGuide: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Shield className="h-8 w-8" />
          Security Implementation Guide
        </h1>
        <Badge variant="outline" className="text-red-600 border-red-600">
          Action Required
        </Badge>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Your platform needs SSL certificates and rate limiting to be production-ready. Follow the guide below to implement essential security measures in under 1 hour.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              SSL Certificate Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Certificate Installed</span>
                <Badge variant="outline" className="text-red-600 border-red-600">
                  Required
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">HTTPS Redirect</span>
                <Badge variant="outline" className="text-red-600 border-red-600">
                  Required
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Rate Limiting Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">DDoS Protection</span>
                <Badge variant="outline" className="text-red-600 border-red-600">
                  Required
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">API Rate Limiting</span>
                <Badge variant="outline" className="text-red-600 border-red-600">
                  Required
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <SecuritySetupInstructions />

      <Card>
        <CardHeader>
          <CardTitle>Additional Security Resources</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a href="https://www.ssllabs.com/ssltest/" target="_blank" rel="noopener noreferrer" className="block p-4 border rounded-lg hover:bg-gray-50">
              <div className="flex items-center gap-2 mb-2">
                <Lock className="h-4 w-4 text-green-600" />
                <span className="font-medium">SSL Labs Test</span>
                <ExternalLink className="h-3 w-3" />
              </div>
              <p className="text-sm text-gray-600">Test your SSL certificate configuration</p>
            </a>
            
            <a href="https://cloudflare.com" target="_blank" rel="noopener noreferrer" className="block p-4 border rounded-lg hover:bg-gray-50">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-blue-600" />
                <span className="font-medium">Cloudflare</span>
                <ExternalLink className="h-3 w-3" />
              </div>
              <p className="text-sm text-gray-600">Free DDoS protection and rate limiting</p>
            </a>
            
            <a href="https://vercel.com" target="_blank" rel="noopener noreferrer" className="block p-4 border rounded-lg hover:bg-gray-50">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-4 w-4 text-purple-600" />
                <span className="font-medium">Vercel</span>
                <ExternalLink className="h-3 w-3" />
              </div>
              <p className="text-sm text-gray-600">Deploy with automatic SSL certificates</p>
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityImplementationGuide;