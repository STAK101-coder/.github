import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Bot, Zap, DollarSign, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { useState } from "react";

const automationFeatures = [
  {
    name: "Smart Pricing",
    description: "AI adjusts prices based on market trends",
    icon: DollarSign,
    active: true,
    savings: "$2,340/month"
  },
  {
    name: "Inventory Sync",
    description: "Auto-sync with suppliers in real-time",
    icon: Bot,
    active: true,
    savings: "15 hours/week"
  },
  {
    name: "Order Processing",
    description: "Automated order fulfillment pipeline",
    icon: Zap,
    active: false,
    savings: "$1,200/month"
  },
  {
    name: "Market Analysis",
    description: "AI-powered trend prediction",
    icon: TrendingUp,
    active: true,
    savings: "8 hours/week"
  }
];

const alerts = [
  { type: "success", message: "Automated 47 orders today", icon: CheckCircle },
  { type: "warning", message: "Low stock alert: 3 products", icon: AlertTriangle },
  { type: "success", message: "Price optimization saved $156", icon: DollarSign }
];

export default function SmartAutomation() {
  const [features, setFeatures] = useState(automationFeatures);

  const toggleFeature = (index: number) => {
    const updated = [...features];
    updated[index].active = !updated[index].active;
    setFeatures(updated);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-900 to-teal-900 text-white border-green-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="w-6 h-6" />
            Smart Automation Hub
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Automation Features</h3>
              <div className="space-y-4">
                {features.map((feature, index) => {
                  const IconComponent = feature.icon;
                  return (
                    <div key={index} className="bg-white/10 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <IconComponent className="w-5 h-5" />
                          <div>
                            <div className="font-medium">{feature.name}</div>
                            <div className="text-sm text-gray-300">{feature.description}</div>
                          </div>
                        </div>
                        <Switch
                          checked={feature.active}
                          onCheckedChange={() => toggleFeature(index)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge variant={feature.active ? 'default' : 'secondary'}>
                          {feature.active ? 'Active' : 'Inactive'}
                        </Badge>
                        <span className="text-sm text-green-400">Saves {feature.savings}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Live Alerts</h3>
              <div className="space-y-3 mb-6">
                {alerts.map((alert, index) => {
                  const IconComponent = alert.icon;
                  return (
                    <div key={index} className={`p-3 rounded-lg flex items-center gap-3 ${
                      alert.type === 'success' ? 'bg-green-600/20 border border-green-500' : 'bg-yellow-600/20 border border-yellow-500'
                    }`}>
                      <IconComponent className={`w-5 h-5 ${
                        alert.type === 'success' ? 'text-green-400' : 'text-yellow-400'
                      }`} />
                      <span className="text-sm">{alert.message}</span>
                    </div>
                  );
                })}
              </div>
              
              <div className="bg-white/10 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Today's Automation Stats</h4>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-green-400">47</div>
                    <div className="text-sm text-gray-300">Orders Processed</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-400">$1,234</div>
                    <div className="text-sm text-gray-300">Revenue Generated</div>
                  </div>
                </div>
              </div>
              
              <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">
                Configure Automation
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}