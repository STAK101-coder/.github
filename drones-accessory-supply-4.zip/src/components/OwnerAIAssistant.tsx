import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Bot, Send, TrendingUp, AlertTriangle, Target, Zap, Brain } from 'lucide-react';

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

const OwnerAIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setMessages([{
      id: '1',
      type: 'ai',
      content: 'Welcome back, Commander! I am your AI Operations Assistant. I have analyzed your platform data and have strategic recommendations ready. How can I assist you today?',
      timestamp: new Date()
    }]);
  }, []);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    setTimeout(() => {
      const aiResponse = generateAIResponse(input);
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: aiResponse,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setLoading(false);
    }, 1500);
  };

  const generateAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('sales') || input.includes('revenue')) {
      return 'Based on your current data, sales are trending upward with a 23% increase this month. Your top-performing category is drone cameras with $45K revenue. I recommend focusing marketing efforts on accessories to increase average order value.';
    }
    
    if (input.includes('inventory') || input.includes('stock')) {
      return 'Inventory analysis shows 5 products below reorder threshold. DJI Mini 3 Pro is your fastest-moving item with 3 days of stock remaining. I have prepared automated reorder suggestions for your review.';
    }
    
    if (input.includes('suppliers') || input.includes('vendor')) {
      return 'Supplier performance metrics: DroneMax (98% on-time), TechWings (95% on-time), SkyGear (87% on-time). I recommend diversifying suppliers for critical products to reduce risk.';
    }
    
    return 'I have analyzed your request. Based on current platform data, I recommend focusing on your top-performing products and optimizing supplier relationships. Would you like specific metrics on any particular area?';
  };

  const insights = [
    {
      id: '1',
      type: 'opportunity',
      title: 'Inventory Optimization',
      description: 'Your drone camera sales are 40% higher than average. Consider increasing stock.',
      priority: 'high',
      action: 'Increase Stock'
    },
    {
      id: '2',
      type: 'warning',
      title: 'Supplier Risk Alert',
      description: 'Supplier DJI-TECH has 15% delayed shipments this month.',
      priority: 'medium',
      action: 'Contact Supplier'
    },
    {
      id: '3',
      type: 'recommendation',
      title: 'Marketing Opportunity',
      description: 'Social media engagement up 25%. Perfect time for product launch campaign.',
      priority: 'high',
      action: 'Launch Campaign'
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-900">
            <Brain className="h-6 w-6" />
            AI Command Center
          </CardTitle>
          <p className="text-blue-700">Your intelligent business operations assistant</p>
        </CardHeader>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              AI Assistant Chat
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="h-64 overflow-y-auto space-y-3 p-4 bg-gray-50 rounded">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs px-4 py-2 rounded-lg ${
                      message.type === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-white border shadow-sm'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                      <p className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-white border shadow-sm px-4 py-2 rounded-lg">
                      <span className="text-sm">AI is thinking...</span>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask me about your business metrics..."
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} disabled={loading}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AI Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.map((insight) => (
                <div key={insight.id} className="p-3 border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-sm">{insight.title}</h4>
                    <Badge variant={insight.priority === 'high' ? 'destructive' : 'secondary'}>
                      {insight.priority}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-2">{insight.description}</p>
                  <Button size="sm" variant="outline" className="w-full">
                    <Zap className="h-3 w-3 mr-1" />
                    {insight.action}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OwnerAIAssistant;