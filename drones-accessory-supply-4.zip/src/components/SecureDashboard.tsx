import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Shield, User, Lock, Eye } from 'lucide-react';

interface User {
  affiliateNumber: string;
  email: string;
  userType: 'customer' | 'subscriber' | 'supplier';
  subscriptionTier: string;
  isActive: boolean;
}

export const SecureDashboard: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [affiliateNumber, setAffiliateNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    try {
      // Simulate authentication
      if (affiliateNumber && email && password) {
        const mockUser: User = {
          affiliateNumber,
          email,
          userType: 'customer',
          subscriptionTier: 'pro',
          isActive: true
        };
        setUser(mockUser);
        setIsAuthenticated(true);
        localStorage.setItem('affiliateAuth', JSON.stringify(mockUser));
      }
    } catch (error) {
      console.error('Login failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('affiliateAuth');
    setAffiliateNumber('');
    setEmail('');
    setPassword('');
  };

  useEffect(() => {
    const savedAuth = localStorage.getItem('affiliateAuth');
    if (savedAuth) {
      const userData = JSON.parse(savedAuth);
      setUser(userData);
      setIsAuthenticated(true);
    }
  }, []);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-black/90 border-red-500">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Shield className="h-12 w-12 text-red-500" />
            </div>
            <CardTitle className="text-2xl text-red-400">SECURE ACCESS</CardTitle>
            <CardDescription className="text-gray-300">
              Enter your affiliate credentials to access your dashboard
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="affiliate" className="text-red-400">Affiliate Number</Label>
              <Input
                id="affiliate"
                type="text"
                value={affiliateNumber}
                onChange={(e) => setAffiliateNumber(e.target.value)}
                className="bg-gray-900 border-red-500 text-white"
                placeholder="DW12345ABCD"
              />
            </div>
            <div>
              <Label htmlFor="email" className="text-red-400">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-gray-900 border-red-500 text-white"
                placeholder="your@email.com"
              />
            </div>
            <div>
              <Label htmlFor="password" className="text-red-400">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-900 border-red-500 text-white"
                placeholder="••••••••"
              />
            </div>
            <Button
              onClick={handleLogin}
              disabled={loading || !affiliateNumber || !email || !password}
              className="w-full bg-red-600 hover:bg-red-700 text-white"
            >
              {loading ? 'AUTHENTICATING...' : 'SECURE LOGIN'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-red-400">SECURE DASHBOARD</h1>
          <Button onClick={handleLogout} variant="outline" className="border-red-500 text-red-400">
            LOGOUT
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-black/90 border-red-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-400">
                <User className="h-5 w-5" />
                User Profile
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-300">Affiliate Number:</span>
                <Badge className="bg-red-600">{user?.affiliateNumber}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Email:</span>
                <span className="text-white">{user?.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">User Type:</span>
                <Badge variant="outline" className="border-red-500 text-red-400">
                  {user?.userType?.toUpperCase()}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Subscription:</span>
                <Badge className="bg-green-600">{user?.subscriptionTier?.toUpperCase()}</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/90 border-red-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-400">
                <Lock className="h-5 w-5" />
                Security Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Account Status:</span>
                <Badge className={user?.isActive ? 'bg-green-600' : 'bg-red-600'}>
                  {user?.isActive ? 'ACTIVE' : 'INACTIVE'}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Access Level:</span>
                <Badge className="bg-yellow-600">RESTRICTED</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Data Protection:</span>
                <Badge className="bg-blue-600">ENCRYPTED</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 bg-black/90 border-red-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-400">
              <Eye className="h-5 w-5" />
              Access Permissions
            </CardTitle>
            <CardDescription className="text-gray-300">
              You can only access data associated with your affiliate number
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gray-900 rounded border border-red-500">
                <h3 className="font-semibold text-red-400 mb-2">Personal Data</h3>
                <p className="text-sm text-gray-300">Access to your profile, orders, and account settings</p>
              </div>
              <div className="p-4 bg-gray-900 rounded border border-red-500">
                <h3 className="font-semibold text-red-400 mb-2">Business Data</h3>
                <p className="text-sm text-gray-300">Access to your business metrics and analytics</p>
              </div>
              <div className="p-4 bg-gray-900 rounded border border-red-500">
                <h3 className="font-semibold text-red-400 mb-2">Restricted Access</h3>
                <p className="text-sm text-gray-300">No access to other users' data or admin functions</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};