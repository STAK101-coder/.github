import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Eye, Target, Brain, AlertCircle } from "lucide-react";

const predictions = [
  {
    product: "Tactical Drone X1",
    currentSales: 45,
    predictedSales: 78,
    trend: "up",
    confidence: 92,
    timeframe: "Next 30 days"
  },
  {
    product: "Combat Drone Pro",
    currentSales: 32,
    predictedSales: 28,
    trend: "down",
    confidence: 87,
    timeframe: "Next 30 days"
  },
  {
    product: "Stealth Recon Unit",
    currentSales: 18,
    predictedSales: 45,
    trend: "up",
    confidence: 95,
    timeframe: "Next 30 days"
  }
];

const marketInsights = [
  {
    title: "Seasonal Demand Spike",
    description: "Military equipment demand increases 40% in Q4",
    impact: "High",
    action: "Increase inventory",
    icon: TrendingUp
  },
  {
    title: "Competitor Price Drop",
    description: "Major competitor reduced prices by 15%",
    impact: "Medium",
    action: "Review pricing strategy",
    icon: AlertCircle
  },
  {
    title: "New Market Opportunity",
    description: "Emerging demand in surveillance category",
    impact: "High",
    action: "Expand product line",
    icon: Target
  }
];

export default function PredictiveAnalytics() {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-indigo-900 to-purple-900 text-white border-indigo-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-6 h-6" />
            Predictive Market Intelligence
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Sales Predictions</h3>
              <div className="space-y-4">
                {predictions.map((pred, index) => (
                  <div key={index} className="bg-white/10 p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{pred.product}</span>
                      <div className="flex items-center gap-2">
                        {pred.trend === 'up' ? (
                          <TrendingUp className="w-4 h-4 text-green-400" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-red-400" />
                        )}
                        <Badge variant={pred.trend === 'up' ? 'default' : 'destructive'}>
                          {pred.trend === 'up' ? '+' : ''}{pred.predictedSales - pred.currentSales}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-sm text-gray-300 mb-2">
                      Current: {pred.currentSales} → Predicted: {pred.predictedSales}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">{pred.confidence}% confidence</span>
                      <span className="text-sm text-gray-400">{pred.timeframe}</span>
                    </div>
                    <Progress value={pred.confidence} className="mt-2" />
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Market Insights</h3>
              <div className="space-y-4">
                {marketInsights.map((insight, index) => {
                  const IconComponent = insight.icon;
                  return (
                    <div key={index} className="bg-white/10 p-4 rounded-lg">
                      <div className="flex items-start gap-3">
                        <IconComponent className="w-5 h-5 mt-1 text-blue-400" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium">{insight.title}</span>
                            <Badge variant={insight.impact === 'High' ? 'destructive' : 'secondary'}>
                              {insight.impact}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-300 mb-2">{insight.description}</p>
                          <div className="text-sm text-blue-400">
                            Recommended: {insight.action}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 bg-white/10 p-4 rounded-lg">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Market Visibility Score
                </h4>
                <div className="text-3xl font-bold text-green-400 mb-2">8.7/10</div>
                <Progress value={87} className="mb-2" />
                <p className="text-sm text-gray-300">
                  Your products have excellent market visibility with strong prediction accuracy.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}