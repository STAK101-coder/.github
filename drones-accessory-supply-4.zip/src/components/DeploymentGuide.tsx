import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { CheckCircle, Globe, Rocket, Server, Shield } from 'lucide-react';

const DeploymentGuide = () => {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">🚀 Deploy Your Drone Platform</h1>
        <p className="text-muted-foreground">Get your platform live in 15 minutes</p>
      </div>

      <Tabs defaultValue="quick" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="quick">Quick Deploy</TabsTrigger>
          <TabsTrigger value="production">Production</TabsTrigger>
          <TabsTrigger value="custom">Custom Domain</TabsTrigger>
        </TabsList>

        <TabsContent value="quick" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Rocket className="h-5 w-5" />
                Instant Deployment (5 minutes)
              </CardTitle>
              <CardDescription>Deploy to Vercel with one click</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Step 1</Badge>
                  <span>Run <code className="bg-muted px-2 py-1 rounded">npm run build</code></span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Step 2</Badge>
                  <span>Connect GitHub repository</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Step 3</Badge>
                  <span>Deploy to Vercel (automatic)</span>
                </div>
              </div>
              <Button className="w-full" size="lg">
                <Globe className="mr-2 h-4 w-4" />
                Deploy to Vercel
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="production" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="h-5 w-5" />
                Production Deployment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold">Environment Setup</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Configure Supabase production</li>
                    <li>• Set environment variables</li>
                    <li>• Enable SSL certificate</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Performance</h4>
                  <ul className="text-sm space-y-1">
                    <li>• CDN optimization</li>
                    <li>• Image compression</li>
                    <li>• Caching strategy</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="custom" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Custom Domain Setup</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Connect your custom domain (e.g., yourdrones.com)
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Purchase domain</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Configure DNS settings</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Enable SSL certificate</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DeploymentGuide;