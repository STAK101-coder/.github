import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Users, Share2, Target, Search, MessageCircle } from "lucide-react";

const TrafficGenerationDashboard = () => {
  const trafficSources = [
    { name: "Google Ads", visitors: 1250, conversion: 3.2, status: "active" },
    { name: "Facebook Ads", visitors: 980, conversion: 2.8, status: "active" },
    { name: "SEO Organic", visitors: 750, conversion: 4.1, status: "growing" },
    { name: "Instagram", visitors: 650, conversion: 2.5, status: "active" },
    { name: "Email Marketing", visitors: 420, conversion: 5.2, status: "high" },
    { name: "YouTube", visitors: 380, conversion: 3.8, status: "growing" }
  ];

  const marketingStrategies = [
    {
      title: "Search Engine Optimization",
      description: "Optimize for drone-related keywords",
      icon: Search,
      tactics: ["Keyword research", "Content creation", "Technical SEO", "Link building"]
    },
    {
      title: "Social Media Marketing",
      description: "Engage on platforms where drone enthusiasts gather",
      icon: Share2,
      tactics: ["Instagram posts", "YouTube demos", "TikTok videos", "Facebook groups"]
    },
    {
      title: "Paid Advertising",
      description: "Target specific demographics and interests",
      icon: Target,
      tactics: ["Google Ads", "Facebook Ads", "Instagram Ads", "YouTube Ads"]
    },
    {
      title: "Content Marketing",
      description: "Create valuable content for your audience",
      icon: MessageCircle,
      tactics: ["Blog posts", "Video tutorials", "Drone reviews", "How-to guides"]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">Traffic Generation</h2>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <TrendingUp className="mr-2 h-4 w-4" />
          Launch Campaign
        </Button>
      </div>

      {/* Current Traffic Sources */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Current Traffic Sources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {trafficSources.map((source, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium">{source.name}</span>
                    <Badge variant={source.status === 'high' ? 'default' : 'secondary'}>
                      {source.status}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-600">
                    {source.visitors} visitors • {source.conversion}% conversion
                  </div>
                </div>
                <Progress value={source.conversion * 10} className="w-20" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Marketing Strategies */}
      <div className="grid md:grid-cols-2 gap-6">
        {marketingStrategies.map((strategy, index) => {
          const IconComponent = strategy.icon;
          return (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <IconComponent className="h-5 w-5 text-blue-600" />
                  {strategy.title}
                </CardTitle>
                <p className="text-sm text-gray-600">{strategy.description}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {strategy.tactics.map((tactic, tacticIndex) => (
                    <div key={tacticIndex} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full" />
                      <span className="text-sm">{tactic}</span>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  Start Campaign
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default TrafficGenerationDashboard;