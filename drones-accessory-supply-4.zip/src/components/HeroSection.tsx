import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, Play, Target, Zap } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-red-900 via-black to-red-900 py-20 overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http://www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23dc2626%22%20fill-opacity%3D%220.1%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%224%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold">
                <span className="bg-gradient-to-r from-red-400 via-orange-500 to-yellow-500 bg-clip-text text-transparent">
                  DRONE WARS
                </span>
                <br />
                <span className="text-white">DROPSHIPPING</span>
              </h1>
              <p className="text-xl text-red-200 leading-relaxed">
                Dominate the skies with military-grade drones and tactical accessories. 
                From reconnaissance missions to aerial supremacy.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
                <Target className="mr-2 h-5 w-5" />
                Deploy Now <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="border-2 border-red-400 text-red-400 hover:bg-red-900 px-8 py-4 rounded-full">
                <Play className="mr-2 h-5 w-5" /> Combat Demo
              </Button>
            </div>
            
            <div className="flex items-center space-x-6 text-red-200">
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-yellow-400" />
                <span>Lightning Fast Delivery</span>
              </div>
              <div className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-red-400" />
                <span>Precision Targeting</span>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative z-10 transform hover:scale-105 transition-transform duration-500">
              <div className="bg-gradient-to-br from-red-600 to-black rounded-3xl p-8 shadow-2xl border border-red-500">
                <div className="bg-black rounded-2xl p-6 text-center border border-red-700">
                  <div className="text-6xl mb-4">🚁</div>
                  <h3 className="text-xl font-bold text-white">Tactical Reaper X1</h3>
                  <p className="text-red-300">Military Grade</p>
                  <div className="text-2xl font-bold text-red-400 mt-2">$2,999</div>
                  <div className="mt-3 px-3 py-1 bg-red-600 text-white text-sm rounded-full inline-block">
                    CLASSIFIED
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -top-4 -right-4 bg-orange-500 rounded-full p-4 shadow-lg animate-pulse">
              <span className="text-white font-bold text-sm">HOT</span>
            </div>
            <div className="absolute -bottom-4 -left-4 bg-red-600 rounded-full p-3 shadow-lg">
              <Target className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;