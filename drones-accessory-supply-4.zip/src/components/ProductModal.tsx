import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, ShoppingCart, Share2 } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import ProductImageGallery from './ProductImageGallery';
import PaymentModal from './PaymentModal';

const ProductModal: React.FC = () => {
  const { selectedProduct, setSelectedProduct } = useAppContext();
  const [showPayment, setShowPayment] = useState(false);

  if (!selectedProduct) return null;

  const {
    name,
    price,
    originalPrice,
    rating,
    reviews,
    category,
    features,
    inStock,
    images
  } = selectedProduct;

  const discount = originalPrice ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;

  const handleBuyNow = () => {
    setShowPayment(true);
  };

  return (
    <>
      <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">{name}</DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Image Gallery */}
            <div>
              <ProductImageGallery images={images} productName={name} />
            </div>
            
            {/* Product Details */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge variant="outline">{category}</Badge>
                {!inStock && (
                  <Badge variant="destructive">Out of Stock</Badge>
                )}
              </div>
              
              {/* Rating */}
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">({reviews} reviews)</span>
              </div>
              
              {/* Price */}
              <div className="flex items-center gap-3">
                <span className="text-3xl font-bold text-blue-600">${price}</span>
                {originalPrice && (
                  <>
                    <span className="text-lg text-gray-500 line-through">${originalPrice}</span>
                    <Badge className="bg-red-500">-{discount}%</Badge>
                  </>
                )}
              </div>
              
              {/* Features */}
              <div>
                <h4 className="font-semibold mb-2">Key Features:</h4>
                <ul className="space-y-1">
                  {features.map((feature, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Action Buttons */}
              <div className="space-y-3">
                <Button 
                  onClick={handleBuyNow}
                  className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-lg py-6"
                  disabled={!inStock}
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  {inStock ? 'Buy Now' : 'Notify When Available'}
                </Button>
                
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1">
                    <Heart className="h-4 w-4 mr-2" />
                    Wishlist
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Share2 className="h-4 w-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      <PaymentModal 
        isOpen={showPayment}
        onClose={() => setShowPayment(false)}
        product={selectedProduct ? { name: selectedProduct.name, price: selectedProduct.price } : null}
      />
    </>
  );
};

export default ProductModal;