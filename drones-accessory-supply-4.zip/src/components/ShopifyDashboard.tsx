import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ShopifyIntegration from './ShopifyIntegration';
import DropshipSettings from './DropshipSettings';
import { ShoppingBag, TrendingUp, Package, DollarSign } from 'lucide-react';

const ShopifyDashboard: React.FC = () => {
  const stats = [
    {
      title: 'Connected Stores',
      value: '2',
      icon: ShoppingBag,
      change: '+1 this month'
    },
    {
      title: 'Total Orders',
      value: '156',
      icon: Package,
      change: '+23% from last month'
    },
    {
      title: 'Revenue',
      value: '$12,450',
      icon: DollarSign,
      change: '+18% from last month'
    },
    {
      title: 'Commission Earned',
      value: '$1,867',
      icon: TrendingUp,
      change: '+25% from last month'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-xs text-green-600">{stat.change}</p>
                  </div>
                  <Icon className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="integration" className="space-y-4">
        <TabsList>
          <TabsTrigger value="integration">Store Integration</TabsTrigger>
          <TabsTrigger value="dropshipping">Dropshipping</TabsTrigger>
        </TabsList>
        
        <TabsContent value="integration">
          <ShopifyIntegration />
        </TabsContent>
        
        <TabsContent value="dropshipping">
          <DropshipSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ShopifyDashboard;