import React from 'react';
import { Facebook, Twitter, Instagram, Youtube, Shield, Target, Zap } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-br from-black via-red-900 to-black text-white py-12 border-t border-red-800">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">
              DRONE WARS
            </h3>
            <p className="text-red-200 text-sm mb-4">
              Elite tactical drones and military-grade accessories for aerial supremacy and reconnaissance missions.
            </p>
            <div className="flex items-center space-x-2 text-red-300">
              <Shield className="h-4 w-4" />
              <span className="text-xs">CLASSIFIED OPERATIONS</span>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-red-300">Arsenal</h4>
            <ul className="space-y-2 text-sm text-red-200">
              <li className="flex items-center space-x-2">
                <Target className="h-3 w-3" />
                <span>Combat Drones</span>
              </li>
              <li className="flex items-center space-x-2">
                <Zap className="h-3 w-3" />
                <span>Tactical Drones</span>
              </li>
              <li className="flex items-center space-x-2">
                <Shield className="h-3 w-3" />
                <span>Recon Drones</span>
              </li>
              <li>Military Accessories</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-red-300">Operations</h4>
            <ul className="space-y-2 text-sm text-red-200">
              <li>Elite Suppliers</li>
              <li>Join Forces</li>
              <li>Security Clearance</li>
              <li>Bulk Deployment</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-red-300">Command Center</h4>
            <div className="flex space-x-4 mb-4">
              <Facebook className="h-5 w-5 text-red-400 hover:text-red-300 cursor-pointer transition-colors" />
              <Twitter className="h-5 w-5 text-red-400 hover:text-red-300 cursor-pointer transition-colors" />
              <Instagram className="h-5 w-5 text-red-400 hover:text-red-300 cursor-pointer transition-colors" />
              <Youtube className="h-5 w-5 text-red-400 hover:text-red-300 cursor-pointer transition-colors" />
            </div>
            <div className="bg-red-900 border border-red-700 rounded p-3">
              <p className="text-xs text-red-200 font-mono">
                STATUS: OPERATIONAL<br/>
                THREAT LEVEL: MINIMAL<br/>
                DRONES DEPLOYED: 1,247
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-red-800 mt-8 pt-8 text-center text-sm text-red-300">
          <p>&copy; 2024 DRONE WARS DROPSHIPPING. All tactical operations reserved.</p>
          <p className="text-xs mt-2 text-red-400">⚠️ CLASSIFIED MATERIAL - AUTHORIZED PERSONNEL ONLY</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;