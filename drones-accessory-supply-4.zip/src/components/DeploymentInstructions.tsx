import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Terminal, ExternalLink, Copy, CheckCircle } from 'lucide-react';

const DeploymentInstructions = () => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Deploy Your Platform</h2>
        <p className="text-muted-foreground">Choose your deployment method</p>
      </div>

      <Tabs defaultValue="vercel" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="vercel">Vercel (Recommended)</TabsTrigger>
          <TabsTrigger value="netlify">Netlify</TabsTrigger>
          <TabsTrigger value="manual">Manual</TabsTrigger>
        </TabsList>

        <TabsContent value="vercel" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5" />
                Deploy to Vercel
                <Badge variant="secondary">5 minutes</Badge>
              </CardTitle>
              <CardDescription>Fastest deployment with automatic SSL</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="bg-muted p-3 rounded-lg">
                  <p className="text-sm font-medium mb-2">1. Build your project:</p>
                  <div className="flex items-center gap-2 bg-black text-white p-2 rounded text-sm font-mono">
                    <span>npm run build</span>
                    <Button size="sm" variant="ghost" onClick={() => copyToClipboard('npm run build')}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <div className="bg-muted p-3 rounded-lg">
                  <p className="text-sm font-medium mb-2">2. Install Vercel CLI:</p>
                  <div className="flex items-center gap-2 bg-black text-white p-2 rounded text-sm font-mono">
                    <span>npm i -g vercel</span>
                    <Button size="sm" variant="ghost" onClick={() => copyToClipboard('npm i -g vercel')}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <div className="bg-muted p-3 rounded-lg">
                  <p className="text-sm font-medium mb-2">3. Deploy:</p>
                  <div className="flex items-center gap-2 bg-black text-white p-2 rounded text-sm font-mono">
                    <span>vercel --prod</span>
                    <Button size="sm" variant="ghost" onClick={() => copyToClipboard('vercel --prod')}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
              
              <Button className="w-full" size="lg">
                <ExternalLink className="mr-2 h-4 w-4" />
                Open Vercel Dashboard
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="netlify" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Deploy to Netlify</CardTitle>
              <CardDescription>Drag & drop deployment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Run <code>npm run build</code></span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Drag 'dist' folder to Netlify</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Get instant live URL</span>
                </div>
              </div>
              
              <Button className="w-full" variant="outline">
                <ExternalLink className="mr-2 h-4 w-4" />
                Open Netlify
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="manual" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Manual Deployment</CardTitle>
              <CardDescription>Deploy to your own server</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm">
                <p>• Build: <code>npm run build</code></p>
                <p>• Upload 'dist' folder to your web server</p>
                <p>• Configure web server (Apache/Nginx)</p>
                <p>• Set up SSL certificate</p>
                <p>• Configure domain DNS</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DeploymentInstructions;