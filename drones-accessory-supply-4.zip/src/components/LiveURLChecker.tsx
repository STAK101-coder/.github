import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Globe, CheckCircle, AlertCircle, ExternalLink, Copy } from 'lucide-react';

const LiveURLChecker = () => {
  const [url, setUrl] = useState('');
  const [status, setStatus] = useState<'idle' | 'checking' | 'online' | 'offline'>('idle');
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const checkURL = async () => {
    if (!url) return;
    
    setStatus('checking');
    try {
      // Simulate URL check - in real app, this would ping the URL
      await new Promise(resolve => setTimeout(resolve, 2000));
      setStatus('online');
      setLastChecked(new Date());
    } catch (error) {
      setStatus('offline');
    }
  };

  const copyURL = () => {
    navigator.clipboard.writeText(url);
  };

  const getStatusBadge = () => {
    switch (status) {
      case 'online':
        return (
          <Badge variant="default" className="bg-green-500">
            <CheckCircle className="h-3 w-3 mr-1" />
            Online
          </Badge>
        );
      case 'offline':
        return (
          <Badge variant="destructive">
            <AlertCircle className="h-3 w-3 mr-1" />
            Offline
          </Badge>
        );
      case 'checking':
        return (
          <Badge variant="secondary">
            Checking...
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          Live Platform Checker
        </CardTitle>
        <CardDescription>
          Check if your deployed platform is online and accessible
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Enter your platform URL (e.g., https://yourdrones.vercel.app)"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="flex-1"
          />
          <Button onClick={checkURL} disabled={!url || status === 'checking'}>
            {status === 'checking' ? 'Checking...' : 'Check'}
          </Button>
        </div>

        {url && (
          <div className="flex items-center justify-between p-3 border rounded-lg">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium truncate">{url}</span>
              {getStatusBadge()}
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={copyURL}>
                <Copy className="h-3 w-3" />
              </Button>
              {status === 'online' && (
                <Button size="sm" variant="ghost" onClick={() => window.open(url, '_blank')}>
                  <ExternalLink className="h-3 w-3" />
                </Button>
              )}
            </div>
          </div>
        )}

        {lastChecked && (
          <p className="text-xs text-muted-foreground">
            Last checked: {lastChecked.toLocaleString()}
          </p>
        )}

        <div className="bg-muted p-3 rounded-lg">
          <h4 className="font-medium mb-2">Common Platform URLs:</h4>
          <div className="space-y-1 text-sm">
            <p>• Vercel: https://yourapp.vercel.app</p>
            <p>• Netlify: https://yourapp.netlify.app</p>
            <p>• Custom: https://yourdomain.com</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LiveURLChecker;