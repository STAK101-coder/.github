import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, Share2, Users, Heart, MessageCircle, TrendingUp } from "lucide-react";

const SocialMediaManager = () => {
  const platforms = [
    {
      name: "Instagram",
      followers: 12500,
      engagement: 4.2,
      posts: 45,
      color: "bg-pink-500"
    },
    {
      name: "Facebook",
      followers: 8900,
      engagement: 3.1,
      posts: 32,
      color: "bg-blue-600"
    },
    {
      name: "YouTube",
      followers: 5600,
      engagement: 6.8,
      posts: 18,
      color: "bg-red-500"
    },
    {
      name: "TikTok",
      followers: 15200,
      engagement: 8.5,
      posts: 28,
      color: "bg-black"
    }
  ];

  const scheduledPosts = [
    {
      platform: "Instagram",
      content: "New DJI Mini 4 Pro unboxing and first flight!",
      time: "Today 3:00 PM",
      type: "Video"
    },
    {
      platform: "YouTube",
      content: "Top 5 Drones for Real Estate Photography",
      time: "Tomorrow 10:00 AM",
      type: "Video"
    },
    {
      platform: "TikTok",
      content: "60-second drone flying tips compilation",
      time: "Tomorrow 6:00 PM",
      type: "Short Video"
    },
    {
      platform: "Facebook",
      content: "Customer spotlight: Amazing aerial shots",
      time: "Friday 2:00 PM",
      type: "Post"
    }
  ];

  const contentIdeas = [
    "Drone flying in golden hour",
    "Before/after editing tutorial",
    "Customer drone photography showcase",
    "Drone maintenance tips",
    "Aerial photography composition guide",
    "Drone laws and safety tips"
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">Social Media Manager</h2>
        <Button className="bg-purple-600 hover:bg-purple-700">
          <Share2 className="mr-2 h-4 w-4" />
          Create Post
        </Button>
      </div>

      {/* Platform Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        {platforms.map((platform, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">{platform.name}</h3>
                <div className={`w-3 h-3 rounded-full ${platform.color}`} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">{platform.followers.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">{platform.engagement}% engagement</span>
                </div>
                <div className="text-xs text-gray-600">{platform.posts} posts this month</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Scheduled Posts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Scheduled Posts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {scheduledPosts.map((post, index) => (
                <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline">{post.platform}</Badge>
                      <Badge variant="secondary">{post.type}</Badge>
                    </div>
                    <p className="text-sm font-medium mb-1">{post.content}</p>
                    <p className="text-xs text-gray-600">{post.time}</p>
                  </div>
                  <Button variant="outline" size="sm">
                    Edit
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Content Creation */}
        <Card>
          <CardHeader>
            <CardTitle>Create New Post</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea placeholder="What's happening with your drone business?" />
            <div className="flex gap-2">
              <Button variant="outline" size="sm">📷 Photo</Button>
              <Button variant="outline" size="sm">🎥 Video</Button>
              <Button variant="outline" size="sm">📅 Schedule</Button>
            </div>
            <Button className="w-full">
              Post to All Platforms
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Content Ideas */}
      <Card>
        <CardHeader>
          <CardTitle>Content Ideas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-3">
            {contentIdeas.map((idea, index) => (
              <div key={index} className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-blue-500" />
                  <span className="text-sm">{idea}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SocialMediaManager;