import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Lock, CheckCircle, ExternalLink, Copy, Globe } from 'lucide-react';

const SSLSetupWizard: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [domain, setDomain] = useState('');
  const [platform, setPlatform] = useState('');
  const [sslStatus, setSSLStatus] = useState('pending');
  
  const steps = [
    { id: 1, title: 'Choose Platform', description: 'Select hosting platform' },
    { id: 2, title: 'Deploy App', description: 'Deploy your application' },
    { id: 3, title: 'Add Domain', description: 'Configure custom domain' },
    { id: 4, title: 'Verify SSL', description: 'Confirm SSL certificate' }
  ];
  
  const platforms = [
    {
      name: 'Vercel',
      description: 'Automatic SSL, easy deployment',
      commands: [
        'npm install -g vercel',
        'vercel --prod',
        'vercel domains add yourdomain.com'
      ],
      time: '5 minutes'
    },
    {
      name: 'Netlify',
      description: 'Free SSL, drag & drop deploy',
      commands: [
        'npm run build',
        'drag dist folder to netlify.com',
        'Add custom domain in settings'
      ],
      time: '10 minutes'
    }
  ];
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };
  
  const checkSSL = () => {
    if (domain) {
      setSSLStatus('checking');
      setTimeout(() => {
        setSSLStatus('active');
      }, 2000);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Lock className="h-6 w-6" />
          SSL Setup Wizard
        </h2>
        <Badge variant="outline" className="text-blue-600 border-blue-600">
          Step {currentStep} of {steps.length}
        </Badge>
      </div>
      
      {/* Progress Steps */}
      <div className="flex items-center justify-between mb-8">
        {steps.map((step, idx) => (
          <div key={step.id} className="flex items-center">
            <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
              currentStep >= step.id ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
            }`}>
              {currentStep > step.id ? <CheckCircle className="h-4 w-4" /> : step.id}
            </div>
            <div className="ml-2 hidden md:block">
              <p className="text-sm font-medium">{step.title}</p>
              <p className="text-xs text-gray-500">{step.description}</p>
            </div>
            {idx < steps.length - 1 && (
              <div className={`w-12 h-0.5 mx-4 ${
                currentStep > step.id ? 'bg-blue-600' : 'bg-gray-200'
              }`} />
            )}
          </div>
        ))}
      </div>
      
      {/* Step Content */}
      {currentStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Choose Your Hosting Platform</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platforms.map((p, idx) => (
                <div key={idx} className={`p-4 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                  platform === p.name ? 'border-blue-500 bg-blue-50' : ''
                }`} onClick={() => setPlatform(p.name)}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold">{p.name}</h3>
                    <Badge variant="outline">{p.time}</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{p.description}</p>
                  <div className="space-y-1">
                    {p.commands.map((cmd, cmdIdx) => (
                      <div key={cmdIdx} className="text-xs font-mono bg-gray-100 p-1 rounded">
                        {cmd}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <Button 
                onClick={() => setCurrentStep(2)} 
                disabled={!platform}
                className="w-full"
              >
                Continue with {platform || 'Selected Platform'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      {currentStep === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Deploy Your Application</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4">
              <Globe className="h-4 w-4" />
              <AlertDescription>
                Follow these commands to deploy to {platform}
              </AlertDescription>
            </Alert>
            
            <div className="space-y-3">
              {platforms.find(p => p.name === platform)?.commands.map((cmd, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <code className="flex-1 bg-gray-100 p-3 rounded text-sm font-mono">
                    {cmd}
                  </code>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(cmd)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            
            <div className="mt-6 flex gap-2">
              <Button variant="outline" onClick={() => setCurrentStep(1)}>Back</Button>
              <Button onClick={() => setCurrentStep(3)} className="flex-1">
                Deployment Complete
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      {currentStep === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Add Custom Domain</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="domain">Your Domain</Label>
                <Input 
                  id="domain"
                  placeholder="yourdomain.com"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                />
              </div>
              
              <Alert>
                <Lock className="h-4 w-4" />
                <AlertDescription>
                  SSL certificate will be automatically provisioned when you add your domain to {platform}.
                </AlertDescription>
              </Alert>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Steps:</h4>
                <ol className="text-sm space-y-1 list-decimal list-inside">
                  <li>Go to your {platform} dashboard</li>
                  <li>Navigate to Domain settings</li>
                  <li>Add custom domain: {domain || 'yourdomain.com'}</li>
                  <li>Update DNS records as instructed</li>
                  <li>Wait for SSL certificate (1-24 hours)</li>
                </ol>
              </div>
            </div>
            
            <div className="mt-6 flex gap-2">
              <Button variant="outline" onClick={() => setCurrentStep(2)}>Back</Button>
              <Button onClick={() => setCurrentStep(4)} disabled={!domain} className="flex-1">
                Domain Added
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      {currentStep === 4 && (
        <Card>
          <CardHeader>
            <CardTitle>Verify SSL Certificate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Input 
                  value={domain}
                  readOnly
                  className="flex-1"
                />
                <Button onClick={checkSSL} disabled={sslStatus === 'checking'}>
                  {sslStatus === 'checking' ? 'Checking...' : 'Check SSL'}
                </Button>
              </div>
              
              {sslStatus === 'active' && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription className="text-green-700">
                    SSL certificate is active! Your site is now secure with HTTPS.
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">SSL Verification Checklist:</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Visit https://{domain || 'yourdomain.com'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Look for padlock icon in browser</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>No security warnings displayed</span>
                  </div>
                </div>
              </div>
              
              <a 
                href={`https://www.ssllabs.com/ssltest/analyze.html?d=${domain}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-blue-600 hover:underline"
              >
                Test SSL Configuration <ExternalLink className="h-4 w-4" />
              </a>
            </div>
            
            <div className="mt-6 flex gap-2">
              <Button variant="outline" onClick={() => setCurrentStep(3)}>Back</Button>
              <Button onClick={() => setCurrentStep(1)} className="flex-1">
                SSL Setup Complete!
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SSLSetupWizard;