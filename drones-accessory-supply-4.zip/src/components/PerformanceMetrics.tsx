import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, TrendingDown, DollarSign, ShoppingCart, Users, Package } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ReactNode;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, change, trend, icon }) => {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className={`flex items-center text-xs ${
          trend === 'up' ? 'text-green-600' : 'text-red-600'
        }`}>
          {trend === 'up' ? (
            <TrendingUp className="h-3 w-3 mr-1" />
          ) : (
            <TrendingDown className="h-3 w-3 mr-1" />
          )}
          {change}
        </div>
      </CardContent>
    </Card>
  );
};

interface PerformanceMetricsProps {
  data: {
    totalRevenue: number;
    totalOrders: number;
    totalProducts: number;
    totalSuppliers: number;
    monthlyRevenue: number;
    weeklyOrders: number;
    conversionRate: number;
    avgOrderValue: number;
  };
}

const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({ data }) => {
  return (
    <div className="space-y-6">
      {/* Key Performance Indicators */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Revenue"
          value={`$${data.totalRevenue.toFixed(2)}`}
          change="+20.1% from last month"
          trend="up"
          icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
        />
        <MetricCard
          title="Total Orders"
          value={data.totalOrders.toString()}
          change={`${data.weeklyOrders} this week`}
          trend="up"
          icon={<ShoppingCart className="h-4 w-4 text-muted-foreground" />}
        />
        <MetricCard
          title="Products"
          value={data.totalProducts.toString()}
          change="Active inventory"
          trend="up"
          icon={<Package className="h-4 w-4 text-muted-foreground" />}
        />
        <MetricCard
          title="Suppliers"
          value={data.totalSuppliers.toString()}
          change="Active partners"
          trend="up"
          icon={<Users className="h-4 w-4 text-muted-foreground" />}
        />
      </div>

      {/* Performance Goals */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Goals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Monthly Revenue Target</span>
              <span>$50,000</span>
            </div>
            <Progress value={(data.monthlyRevenue / 50000) * 100} className="h-2" />
            <p className="text-xs text-muted-foreground mt-1">
              ${data.monthlyRevenue.toFixed(2)} of $50,000 ({((data.monthlyRevenue / 50000) * 100).toFixed(1)}%)
            </p>
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Conversion Rate Target</span>
              <span>5.0%</span>
            </div>
            <Progress value={(data.conversionRate / 5) * 100} className="h-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {data.conversionRate}% of 5.0% ({((data.conversionRate / 5) * 100).toFixed(1)}%)
            </p>
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Average Order Value Target</span>
              <span>$200</span>
            </div>
            <Progress value={(data.avgOrderValue / 200) * 100} className="h-2" />
            <p className="text-xs text-muted-foreground mt-1">
              ${data.avgOrderValue.toFixed(2)} of $200 ({((data.avgOrderValue / 200) * 100).toFixed(1)}%)
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PerformanceMetrics;