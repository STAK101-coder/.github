import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, Target, TrendingUp, Award, BookOpen, MessageSquare } from "lucide-react";

const trainingModules = [
  {
    title: "Market Intelligence",
    progress: 85,
    status: "In Progress",
    icon: Brain,
    lessons: 12,
    completed: 10
  },
  {
    title: "Supplier Negotiations",
    progress: 60,
    status: "Active",
    icon: Target,
    lessons: 8,
    completed: 5
  },
  {
    title: "Profit Optimization",
    progress: 100,
    status: "Completed",
    icon: TrendingUp,
    lessons: 15,
    completed: 15
  }
];

const achievements = [
  { name: "First Sale", earned: true, icon: Award },
  { name: "$1K Revenue", earned: true, icon: TrendingUp },
  { name: "10 Products", earned: false, icon: Target },
  { name: "Market Expert", earned: false, icon: Brain }
];

export default function AIPersonalTrainer() {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-900 to-blue-900 text-white border-purple-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-6 h-6" />
            AI Personal Business Trainer
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Training Progress</h3>
              <div className="space-y-4">
                {trainingModules.map((module, index) => {
                  const IconComponent = module.icon;
                  return (
                    <div key={index} className="bg-white/10 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <IconComponent className="w-5 h-5" />
                          <span className="font-medium">{module.title}</span>
                        </div>
                        <Badge variant={module.status === 'Completed' ? 'default' : 'secondary'}>
                          {module.status}
                        </Badge>
                      </div>
                      <Progress value={module.progress} className="mb-2" />
                      <div className="text-sm text-gray-300">
                        {module.completed}/{module.lessons} lessons completed
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Achievements</h3>
              <div className="grid grid-cols-2 gap-3">
                {achievements.map((achievement, index) => {
                  const IconComponent = achievement.icon;
                  return (
                    <div key={index} className={`p-3 rounded-lg text-center ${achievement.earned ? 'bg-green-600' : 'bg-gray-600'}`}>
                      <IconComponent className="w-6 h-6 mx-auto mb-2" />
                      <div className="text-sm font-medium">{achievement.name}</div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 space-y-3">
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Chat with AI Trainer
                </Button>
                <Button variant="outline" className="w-full">
                  <BookOpen className="w-4 h-4 mr-2" />
                  View Learning Path
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}