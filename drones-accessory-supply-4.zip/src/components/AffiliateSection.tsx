import React from 'react';
import AffiliateCard from './AffiliateCard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const affiliatePrograms = [
  {
    id: '1',
    name: 'DJI Affiliate Program',
    description: 'Official DJI partner program with premium drone products',
    commission: '3-8%',
    category: 'Premium Drones',
    rating: 4.8,
    joinUrl: 'https://affiliate.dji.com',
    features: ['High-quality products', 'Brand recognition', 'Marketing support'],
    paymentTerms: 'Monthly via PayPal',
    logo: '🚁'
  },
  {
    id: '2',
    name: 'Amazon Associates',
    description: 'Promote drone products from the world\'s largest marketplace',
    commission: '1-10%',
    category: 'Marketplace',
    rating: 4.5,
    joinUrl: 'https://associates.amazon.com',
    features: ['Huge product selection', 'Trusted platform', 'Easy integration'],
    paymentTerms: 'Monthly direct deposit',
    logo: '📦'
  },
  {
    id: '3',
    name: 'Best Buy Affiliate',
    description: 'Electronics retailer with extensive drone inventory',
    commission: '1-4%',
    category: 'Electronics',
    rating: 4.3,
    joinUrl: 'https://affiliate.bestbuy.com',
    features: ['Retail credibility', 'Local pickup options', 'Price matching'],
    paymentTerms: 'Monthly check/ACH',
    logo: '🏪'
  },
  {
    id: '4',
    name: 'B&H Photo Affiliate',
    description: 'Professional photography and drone equipment specialist',
    commission: '1-6%',
    category: 'Professional',
    rating: 4.7,
    joinUrl: 'https://www.bhphotovideo.com/affiliate',
    features: ['Professional grade', 'Expert reviews', 'Educational content'],
    paymentTerms: 'Monthly via check',
    logo: '📸'
  },
  {
    id: '5',
    name: 'Banggood Affiliate',
    description: 'Global online store with competitive drone prices',
    commission: '2-12%',
    category: 'International',
    rating: 4.2,
    joinUrl: 'https://affiliate.banggood.com',
    features: ['Competitive prices', 'Global shipping', 'Wide selection'],
    paymentTerms: 'Weekly/Monthly PayPal',
    logo: '🌐'
  },
  {
    id: '6',
    name: 'GetFPV Affiliate',
    description: 'Specialized FPV and racing drone equipment',
    commission: '3-8%',
    category: 'FPV/Racing',
    rating: 4.6,
    joinUrl: 'https://www.getfpv.com/affiliate',
    features: ['FPV specialization', 'Racing community', 'Technical support'],
    paymentTerms: 'Monthly commission',
    logo: '🏁'
  }
];

const AffiliateSection: React.FC = () => {
  const categories = ['All', 'Premium Drones', 'Marketplace', 'Electronics', 'Professional', 'International', 'FPV/Racing'];
  
  const filterByCategory = (category: string) => {
    if (category === 'All') return affiliatePrograms;
    return affiliatePrograms.filter(program => program.category === category);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Affiliate <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Marketing</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join top affiliate programs and earn commissions promoting drone products
          </p>
        </div>
        
        <Tabs defaultValue="All" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7 mb-8">
            {categories.map((category) => (
              <TabsTrigger key={category} value={category} className="text-xs">
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {categories.map((category) => (
            <TabsContent key={category} value={category}>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {filterByCategory(category).map((affiliate) => (
                  <AffiliateCard key={affiliate.id} affiliate={affiliate} />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
        
        <div className="text-center">
          <Button size="lg" variant="outline" className="px-8 py-3">
            View More Programs
          </Button>
        </div>
      </div>
    </section>
  );
};

export default AffiliateSection;