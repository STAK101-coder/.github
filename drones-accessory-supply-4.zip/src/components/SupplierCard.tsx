import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Users, Award, Phone, Mail } from 'lucide-react';

interface SupplierCardProps {
  supplier: {
    id: string;
    name: string;
    location: string;
    rating: number;
    reviews: number;
    specialties: string[];
    verified: boolean;
    yearsActive: number;
    logo: string;
    minOrder?: string;
    paymentTerms?: string;
    shippingTime?: string;
    contact?: {
      phone?: string;
      email?: string;
    };
  };
}

const SupplierCard: React.FC<SupplierCardProps> = ({ supplier }) => {
  return (
    <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-gradient-to-br from-white to-gray-50 hover:scale-105">
      <CardContent className="p-6">
        <div className="text-center mb-4">
          <div className="text-4xl mb-3">{supplier.logo}</div>
          <div className="flex items-center justify-center mb-2">
            <h3 className="font-bold text-lg text-gray-800">{supplier.name}</h3>
            {supplier.verified && (
              <Award className="h-4 w-4 text-green-500 ml-2" />
            )}
          </div>
          <div className="flex items-center justify-center text-gray-600 text-sm mb-3">
            <MapPin className="h-3 w-3 mr-1" />
            {supplier.location}
          </div>
        </div>
        
        <div className="flex items-center justify-center mb-3">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-400 fill-current" />
            <span className="font-semibold ml-1">{supplier.rating}</span>
          </div>
          <span className="text-sm text-gray-600 ml-2">({supplier.reviews} reviews)</span>
        </div>
        
        <div className="space-y-2 mb-4">
          {supplier.specialties.slice(0, 2).map((specialty, index) => (
            <Badge key={index} variant="secondary" className="text-xs mr-1">
              {specialty}
            </Badge>
          ))}
        </div>
        
        <div className="space-y-2 mb-4 text-xs text-gray-600">
          <div className="flex items-center justify-between">
            <span>Experience:</span>
            <span className="flex items-center">
              <Users className="h-3 w-3 mr-1" />
              {supplier.yearsActive} years
            </span>
          </div>
          {supplier.minOrder && (
            <div className="flex items-center justify-between">
              <span>Min Order:</span>
              <span>{supplier.minOrder}</span>
            </div>
          )}
          {supplier.shippingTime && (
            <div className="flex items-center justify-between">
              <span>Shipping:</span>
              <span>{supplier.shippingTime}</span>
            </div>
          )}
        </div>
        
        <div className="space-y-2 mb-4">
          {supplier.contact?.phone && (
            <div className="flex items-center text-xs text-gray-600">
              <Phone className="h-3 w-3 mr-2" />
              {supplier.contact.phone}
            </div>
          )}
          {supplier.contact?.email && (
            <div className="flex items-center text-xs text-gray-600">
              <Mail className="h-3 w-3 mr-2" />
              {supplier.contact.email}
            </div>
          )}
        </div>
        
        <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700">
          Contact Supplier
        </Button>
      </CardContent>
    </Card>
  );
};

export default SupplierCard;