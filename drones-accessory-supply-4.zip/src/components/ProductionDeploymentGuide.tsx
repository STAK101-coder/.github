import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ExternalLink, Copy, Terminal, Globe, Zap } from 'lucide-react';

const ProductionDeploymentGuide = () => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">🚀 Production Deployment Guide</h2>
        <p className="text-gray-600">Deploy your Drone Wars platform in minutes</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-blue-600" />
              Deploy to Vercel
              <Badge className="bg-blue-100 text-blue-700">Recommended</Badge>
            </CardTitle>
            <CardDescription>Fastest deployment with automatic CI/CD</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">1. Install Vercel CLI:</p>
              <div className="bg-gray-100 p-2 rounded flex items-center justify-between">
                <code className="text-sm">npm i -g vercel</code>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard('npm i -g vercel')}>
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium">2. Deploy:</p>
              <div className="bg-gray-100 p-2 rounded flex items-center justify-between">
                <code className="text-sm">vercel --prod</code>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard('vercel --prod')}>
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <Button className="w-full" asChild>
              <a href="https://vercel.com" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" />
                Open Vercel Dashboard
              </a>
            </Button>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-green-600" />
              Deploy to Netlify
              <Badge variant="outline" className="bg-green-50 text-green-700">Popular</Badge>
            </CardTitle>
            <CardDescription>Great for static sites with form handling</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">1. Build command:</p>
              <div className="bg-gray-100 p-2 rounded flex items-center justify-between">
                <code className="text-sm">npm run build</code>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard('npm run build')}>
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium">2. Publish directory:</p>
              <div className="bg-gray-100 p-2 rounded flex items-center justify-between">
                <code className="text-sm">dist</code>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard('dist')}>
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <Button className="w-full" variant="outline" asChild>
              <a href="https://netlify.com" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" />
                Open Netlify Dashboard
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            Pre-Deployment Checklist
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <h4 className="font-semibold">✅ Technical Requirements</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Node.js 18+ installed
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Dependencies installed
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Build process tested
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Supabase configured
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold">✅ Business Requirements</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Domain name ready
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  SSL certificate (auto)
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Payment processing
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Content reviewed
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-yellow-50 border-yellow-200">
        <CardHeader>
          <CardTitle className="text-yellow-800">⚡ Quick Deploy Commands</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="font-medium mb-2">Test build locally:</p>
              <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm">
                npm run build && npm run preview
              </div>
            </div>
            <div>
              <p className="font-medium mb-2">Deploy to Vercel (one command):</p>
              <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm">
                npx vercel --prod
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProductionDeploymentGuide;