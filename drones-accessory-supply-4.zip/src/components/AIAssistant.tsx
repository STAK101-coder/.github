import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Bot, Send, CheckCircle, Clock } from 'lucide-react';

interface Task {
  id: string;
  description: string;
  status: 'pending' | 'completed';
  createdAt: Date;
}

const AIAssistant = () => {
  const [message, setMessage] = useState('');
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      description: 'Update inventory levels for low stock items',
      status: 'completed',
      createdAt: new Date(Date.now() - 3600000)
    },
    {
      id: '2', 
      description: 'Process pending orders and send notifications',
      status: 'completed',
      createdAt: new Date(Date.now() - 1800000)
    }
  ]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    const newTask: Task = {
      id: Date.now().toString(),
      description: message,
      status: 'pending',
      createdAt: new Date()
    };
    
    setTasks(prev => [newTask, ...prev]);
    setMessage('');
    
    setTimeout(() => {
      setTasks(prev => prev.map(task => 
        task.id === newTask.id ? { ...task, status: 'completed' } : task
      ));
    }, 2000);
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          AI Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Ask AI to handle a task..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          />
          <Button onClick={handleSendMessage} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        <ScrollArea className="h-96">
          <div className="space-y-3">
            {tasks.map((task) => (
              <div key={task.id} className="p-3 border rounded-lg">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className="text-sm font-medium">{task.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {task.createdAt.toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {task.status === 'completed' ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <Clock className="h-4 w-4 text-blue-500" />
                    )}
                    <Badge variant={task.status === 'completed' ? 'default' : 'secondary'}>
                      {task.status}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default AIAssistant;