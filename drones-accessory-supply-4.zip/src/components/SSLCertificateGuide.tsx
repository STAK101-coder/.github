import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, CheckCircle, AlertTriangle, Copy, ExternalLink } from 'lucide-react';

const SSLCertificateGuide: React.FC = () => {
  const [copiedText, setCopiedText] = useState('');

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(''), 2000);
  };

  const deploymentPlatforms = [
    {
      name: 'Vercel',
      sslStatus: 'Automatic',
      description: 'SSL certificates are automatically provisioned and renewed',
      steps: [
        'Connect your GitHub repository to Vercel',
        'Deploy your app - SSL is enabled by default',
        'Custom domains get automatic SSL certificates',
        'Certificates auto-renew every 90 days'
      ]
    },
    {
      name: 'Netlify',
      sslStatus: 'Automatic',
      description: 'Free SSL certificates with automatic renewal',
      steps: [
        'Deploy your site to Netlify',
        'Add custom domain in Site Settings',
        'SSL certificate is automatically provisioned',
        'HTTPS redirect is enabled by default'
      ]
    },
    {
      name: 'Cloudflare',
      sslStatus: 'Free + Advanced',
      description: 'Free SSL with additional security features',
      steps: [
        'Add your domain to Cloudflare',
        'Update nameservers to Cloudflare',
        'Enable SSL/TLS encryption (Full/Strict)',
        'Configure security rules and rate limiting'
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Lock className="h-6 w-6" />
          SSL Certificate Setup Guide
        </h2>
        <Badge variant="outline" className="text-blue-600 border-blue-600">
          Security Implementation
        </Badge>
      </div>

      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          SSL certificates encrypt data between your users and your platform. Modern hosting platforms provide free SSL certificates automatically.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="platforms" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="platforms">Hosting Platforms</TabsTrigger>
          <TabsTrigger value="custom">Custom Domain</TabsTrigger>
          <TabsTrigger value="verification">SSL Verification</TabsTrigger>
        </TabsList>

        <TabsContent value="platforms" className="space-y-4">
          <div className="grid gap-4">
            {deploymentPlatforms.map((platform, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      {platform.name}
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        {platform.sslStatus}
                      </Badge>
                    </CardTitle>
                  </div>
                  <p className="text-sm text-gray-600">{platform.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {platform.steps.map((step, stepIndex) => (
                      <div key={stepIndex} className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{step}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="custom" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Custom Domain SSL Setup</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold">1. Purchase Domain</h4>
                <p className="text-sm text-gray-600">Buy domain from registrars like Namecheap, GoDaddy, or Google Domains</p>
                
                <h4 className="font-semibold">2. Configure DNS</h4>
                <div className="bg-gray-50 p-3 rounded border">
                  <p className="text-sm font-mono">A Record: @ → Your hosting IP</p>
                  <p className="text-sm font-mono">CNAME: www → your-domain.com</p>
                </div>
                
                <h4 className="font-semibold">3. SSL Certificate Options</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="border rounded p-3">
                    <h5 className="font-medium text-green-600">Free Options</h5>
                    <ul className="text-sm text-gray-600 mt-1 space-y-1">
                      <li>• Let's Encrypt (Most popular)</li>
                      <li>• Cloudflare SSL</li>
                      <li>• Hosting provider SSL</li>
                    </ul>
                  </div>
                  <div className="border rounded p-3">
                    <h5 className="font-medium text-blue-600">Paid Options</h5>
                    <ul className="text-sm text-gray-600 mt-1 space-y-1">
                      <li>• Extended Validation (EV)</li>
                      <li>• Organization Validated (OV)</li>
                      <li>• Wildcard certificates</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="verification" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SSL Certificate Verification</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold">Quick SSL Check Tools</h4>
                <div className="grid gap-3">
                  <Button 
                    variant="outline" 
                    className="justify-start h-auto p-4"
                    onClick={() => window.open('https://www.ssllabs.com/ssltest/', '_blank')}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    <div className="text-left">
                      <div className="font-medium">SSL Labs Test</div>
                      <div className="text-sm text-gray-600">Comprehensive SSL analysis</div>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="justify-start h-auto p-4"
                    onClick={() => window.open('https://www.whynopadlock.com/', '_blank')}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    <div className="text-left">
                      <div className="font-medium">Why No Padlock</div>
                      <div className="text-sm text-gray-600">Debug mixed content issues</div>
                    </div>
                  </Button>
                </div>
                
                <h4 className="font-semibold mt-6">Browser Verification</h4>
                <div className="bg-gray-50 p-4 rounded border space-y-2">
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Look for padlock icon in address bar</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">URL should start with https://</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Click padlock to view certificate details</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SSLCertificateGuide;