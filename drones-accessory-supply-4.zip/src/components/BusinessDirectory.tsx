import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Building2, Globe, Mail, Phone, MapPin, Search } from 'lucide-react';

const BusinessDirectory: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const businesses = [
    {
      id: '1',
      name: 'TechFlow Solutions',
      type: 'service',
      description: 'Digital marketing and web development services for small businesses',
      website: 'https://techflow.com',
      email: 'contact@techflow.com',
      phone: '(555) 123-4567',
      address: '123 Tech St, Silicon Valley, CA',
      category: 'seo',
      status: 'active',
      joinedDate: '2024-01-15'
    },
    {
      id: '2',
      name: 'Eco Drone Store',
      type: 'ecommerce',
      description: 'Sustainable drone technology and accessories for environmental monitoring',
      website: 'https://ecodrones.com',
      email: 'info@ecodrones.com',
      phone: '(555) 987-6543',
      address: '456 Green Ave, Portland, OR',
      category: 'ecommerce',
      status: 'active',
      joinedDate: '2024-02-20'
    },
    {
      id: '3',
      name: 'Local Fitness Hub',
      type: 'service',
      description: 'Personal training and fitness coaching with digital marketing focus',
      email: 'hello@fitnesshub.com',
      phone: '(555) 456-7890',
      address: '789 Fitness Blvd, Austin, TX',
      category: 'local',
      status: 'active',
      joinedDate: '2024-03-10'
    }
  ];

  const filteredBusinesses = businesses.filter(business => 
    business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Building2 className="w-6 h-6" />
            Business Directory
          </h2>
          <p className="text-gray-600 mt-1">
            {filteredBusinesses.length} businesses registered on the platform
          </p>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Search businesses..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBusinesses.map((business) => (
          <Card key={business.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{business.name}</CardTitle>
                  <CardDescription className="capitalize">
                    {business.type.replace('-', ' ')}
                  </CardDescription>
                </div>
                <Badge className="bg-green-100 text-green-800">
                  {business.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600 line-clamp-2">
                {business.description}
              </p>
              
              <div className="space-y-2">
                {business.website && (
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="w-4 h-4 text-gray-400" />
                    <a href={business.website} target="_blank" rel="noopener noreferrer" 
                       className="text-blue-600 hover:underline truncate">
                      {business.website.replace('https://', '')}
                    </a>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-gray-400" />
                  <span className="truncate">{business.email}</span>
                </div>
                {business.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <span>{business.phone}</span>
                  </div>
                )}
                {business.address && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="truncate">{business.address}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-2">
                <Badge variant="outline">
                  {business.category}
                </Badge>
                <span className="text-xs text-gray-500">
                  Joined {new Date(business.joinedDate).toLocaleDateString()}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBusinesses.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Building2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No businesses found</h3>
            <p className="text-gray-500">Try adjusting your search</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default BusinessDirectory;