import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Users, Award, Phone, Mail } from 'lucide-react';

const suppliers = [
  {
    id: '1',
    name: 'SkyTech Solutions',
    location: 'California, USA',
    rating: 4.9,
    reviews: 1247,
    specialties: ['DJI Products', 'Professional Drones', 'Accessories'],
    verified: true,
    yearsActive: 8,
    logo: '🏢',
    minOrder: '$500',
    contact: { phone: '+1-555-0123', email: 'sales@skytech.com' }
  },
  {
    id: '2',
    name: 'DroneWorld Express',
    location: 'Texas, USA',
    rating: 4.7,
    reviews: 892,
    specialties: ['Racing Drones', 'FPV Equipment', 'Custom Builds'],
    verified: true,
    yearsActive: 5,
    logo: '🌟',
    minOrder: '$250',
    contact: { phone: '+1-555-0456', email: 'info@droneworld.com' }
  },
  {
    id: '3',
    name: 'AerialPro Distributors',
    location: 'New York, USA',
    rating: 4.8,
    reviews: 634,
    specialties: ['Commercial Drones', 'Industrial Solutions', 'Training'],
    verified: true,
    yearsActive: 12,
    logo: '🚀',
    minOrder: '$1000',
    contact: { email: 'contact@aerialpro.com' }
  },
  {
    id: '4',
    name: 'Global Drone Supply',
    location: 'International',
    rating: 4.6,
    reviews: 2156,
    specialties: ['Wholesale', 'Bulk Orders', 'OEM Parts'],
    verified: true,
    yearsActive: 15,
    logo: '🌍',
    minOrder: '$2000',
    contact: { phone: '+86-138-0013-8000', email: 'global@dronesupply.com' }
  }
];

const affiliates = [
  {
    id: '1',
    name: 'DJI Affiliate Program',
    description: 'Official DJI partner program with premium drone products',
    commission: '3-8%',
    category: 'Premium Drones',
    rating: 4.8,
    logo: '🚁'
  },
  {
    id: '2',
    name: 'Amazon Associates',
    description: 'Promote drone products from the worlds largest marketplace',
    commission: '1-10%',
    category: 'Marketplace',
    rating: 4.5,
    logo: '📦'
  },
  {
    id: '3',
    name: 'Best Buy Affiliate',
    description: 'Electronics retailer with extensive drone inventory',
    commission: '1-4%',
    category: 'Electronics',
    rating: 4.3,
    logo: '🏪'
  },
  {
    id: '4',
    name: 'B&H Photo Affiliate',
    description: 'Professional photography and drone equipment specialist',
    commission: '1-6%',
    category: 'Professional',
    rating: 4.7,
    logo: '📸'
  }
];

const SupplierSection: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Suppliers Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Drone <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">Suppliers</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Connect with verified suppliers worldwide for the best deals and authentic products
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {suppliers.map((supplier) => (
              <Card key={supplier.id} className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-gradient-to-br from-white to-gray-50 hover:scale-105">
                <CardContent className="p-6">
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-3">{supplier.logo}</div>
                    <div className="flex items-center justify-center mb-2">
                      <h3 className="font-bold text-lg text-gray-800">{supplier.name}</h3>
                      {supplier.verified && (
                        <Award className="h-4 w-4 text-green-500 ml-2" />
                      )}
                    </div>
                    <div className="flex items-center justify-center text-gray-600 text-sm mb-3">
                      <MapPin className="h-3 w-3 mr-1" />
                      {supplier.location}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center mb-3">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="font-semibold ml-1">{supplier.rating}</span>
                    </div>
                    <span className="text-sm text-gray-600 ml-2">({supplier.reviews} reviews)</span>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    {supplier.specialties.slice(0, 2).map((specialty, index) => (
                      <Badge key={index} variant="secondary" className="text-xs mr-1">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="text-center text-xs text-gray-500 mb-4">
                    <Users className="h-3 w-3 inline mr-1" />
                    {supplier.yearsActive} years • Min: {supplier.minOrder}
                  </div>
                  
                  <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700">
                    Contact Supplier
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Affiliates Section */}
      <section className="py-16 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Affiliate <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Marketing</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join top affiliate programs and earn commissions promoting drone products
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {affiliates.map((affiliate) => (
              <Card key={affiliate.id} className="group hover:shadow-xl transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50 hover:scale-105">
                <CardContent className="p-6">
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-3">{affiliate.logo}</div>
                    <h3 className="font-bold text-lg text-gray-800 mb-2">{affiliate.name}</h3>
                    <p className="text-sm text-gray-600 mb-3">{affiliate.description}</p>
                  </div>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Commission:</span>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        {affiliate.commission}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Rating:</span>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                        <span className="font-semibold">{affiliate.rating}/5</span>
                      </div>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Join Program
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default SupplierSection;