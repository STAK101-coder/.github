import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Shield, Lock, CheckCircle, AlertCircle } from 'lucide-react';

interface PaymentSecurityProps {
  onPaymentSubmit: (paymentData: any) => void;
  amount: number;
}

const PaymentSecurity: React.FC<PaymentSecurityProps> = ({ onPaymentSubmit, amount }) => {
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: ''
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const validateCard = (cardNumber: string) => {
    const cleaned = cardNumber.replace(/\s/g, '');
    return cleaned.length >= 13 && cleaned.length <= 19 && /^\d+$/.test(cleaned);
  };

  const validateExpiry = (expiry: string) => {
    const [month, year] = expiry.split('/');
    if (!month || !year) return false;
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear() % 100;
    const currentMonth = currentDate.getMonth() + 1;
    const expMonth = parseInt(month);
    const expYear = parseInt(year);
    return expMonth >= 1 && expMonth <= 12 && 
           (expYear > currentYear || (expYear === currentYear && expMonth >= currentMonth));
  };

  const validateCVV = (cvv: string) => {
    return cvv.length >= 3 && cvv.length <= 4 && /^\d+$/.test(cvv);
  };

  const handleInputChange = (field: string, value: string) => {
    let formattedValue = value;
    
    if (field === 'cardNumber') {
      formattedValue = value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim();
    } else if (field === 'expiryDate') {
      formattedValue = value.replace(/\D/g, '').replace(/(\d{2})(\d{2})/, '$1/$2');
    } else if (field === 'cvv') {
      formattedValue = value.replace(/\D/g, '').slice(0, 4);
    }
    
    setPaymentData(prev => ({ ...prev, [field]: formattedValue }));
    
    // Clear validation error when user starts typing
    if (validationErrors[field]) {
      setValidationErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const errors: Record<string, string> = {};
    
    if (!validateCard(paymentData.cardNumber)) {
      errors.cardNumber = 'Invalid card number';
    }
    if (!validateExpiry(paymentData.expiryDate)) {
      errors.expiryDate = 'Invalid expiry date';
    }
    if (!validateCVV(paymentData.cvv)) {
      errors.cvv = 'Invalid CVV';
    }
    if (!paymentData.cardholderName.trim()) {
      errors.cardholderName = 'Cardholder name is required';
    }
    
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }
    
    setIsProcessing(true);
    
    // Simulate secure payment processing
    setTimeout(() => {
      const tokenizedData = {
        token: 'tok_' + Math.random().toString(36).substr(2, 9),
        amount,
        currency: 'USD',
        last4: paymentData.cardNumber.slice(-4),
        brand: 'visa' // Would be detected from card number
      };
      
      onPaymentSubmit(tokenizedData);
      setIsProcessing(false);
    }, 2000);
  };

  const securityFeatures = [
    'PCI DSS Compliant',
    '256-bit SSL Encryption',
    'Tokenized Payments',
    'Fraud Detection'
  ];

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Secure Payment
        </CardTitle>
        <div className="flex items-center gap-2 text-sm text-green-600">
          <Shield className="h-4 w-4" />
          <span>Your payment is protected</span>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="cardNumber">Card Number</Label>
            <Input
              id="cardNumber"
              placeholder="1234 5678 9012 3456"
              value={paymentData.cardNumber}
              onChange={(e) => handleInputChange('cardNumber', e.target.value)}
              maxLength={19}
              className={validationErrors.cardNumber ? 'border-red-500' : ''}
            />
            {validationErrors.cardNumber && (
              <p className="text-sm text-red-500 mt-1">{validationErrors.cardNumber}</p>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="expiryDate">Expiry Date</Label>
              <Input
                id="expiryDate"
                placeholder="MM/YY"
                value={paymentData.expiryDate}
                onChange={(e) => handleInputChange('expiryDate', e.target.value)}
                maxLength={5}
                className={validationErrors.expiryDate ? 'border-red-500' : ''}
              />
              {validationErrors.expiryDate && (
                <p className="text-sm text-red-500 mt-1">{validationErrors.expiryDate}</p>
              )}
            </div>
            <div>
              <Label htmlFor="cvv">CVV</Label>
              <Input
                id="cvv"
                placeholder="123"
                value={paymentData.cvv}
                onChange={(e) => handleInputChange('cvv', e.target.value)}
                maxLength={4}
                className={validationErrors.cvv ? 'border-red-500' : ''}
              />
              {validationErrors.cvv && (
                <p className="text-sm text-red-500 mt-1">{validationErrors.cvv}</p>
              )}
            </div>
          </div>
          
          <div>
            <Label htmlFor="cardholderName">Cardholder Name</Label>
            <Input
              id="cardholderName"
              placeholder="John Doe"
              value={paymentData.cardholderName}
              onChange={(e) => handleInputChange('cardholderName', e.target.value)}
              className={validationErrors.cardholderName ? 'border-red-500' : ''}
            />
            {validationErrors.cardholderName && (
              <p className="text-sm text-red-500 mt-1">{validationErrors.cardholderName}</p>
            )}
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between text-lg font-bold">
              <span>Total:</span>
              <span>${amount}</span>
            </div>
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-green-600 hover:bg-green-700"
            disabled={isProcessing}
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processing...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Pay Securely
              </div>
            )}
          </Button>
        </form>
        
        <div className="mt-4 pt-4 border-t">
          <p className="text-sm font-medium mb-2">Security Features:</p>
          <div className="grid grid-cols-2 gap-2">
            {securityFeatures.map((feature, index) => (
              <div key={index} className="flex items-center gap-1 text-xs text-gray-600">
                <CheckCircle className="h-3 w-3 text-green-600" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PaymentSecurity;