import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, TrendingUp, DollarSign, Users } from 'lucide-react';

interface AffiliateCardProps {
  affiliate: {
    id: string;
    name: string;
    description: string;
    commission: string;
    category: string;
    rating: number;
    joinUrl: string;
    features: string[];
    paymentTerms: string;
    logo: string;
  };
}

const AffiliateCard: React.FC<AffiliateCardProps> = ({ affiliate }) => {
  return (
    <Card className="group hover:shadow-xl transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50 hover:scale-105">
      <CardContent className="p-6">
        <div className="text-center mb-4">
          <div className="text-4xl mb-3">{affiliate.logo}</div>
          <h3 className="font-bold text-lg text-gray-800 mb-2">{affiliate.name}</h3>
          <p className="text-sm text-gray-600 mb-3">{affiliate.description}</p>
        </div>
        
        <div className="space-y-3 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Commission:</span>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <DollarSign className="h-3 w-3 mr-1" />
              {affiliate.commission}
            </Badge>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Category:</span>
            <Badge variant="outline">{affiliate.category}</Badge>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Rating:</span>
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 text-yellow-400 mr-1" />
              <span className="font-semibold">{affiliate.rating}/5</span>
            </div>
          </div>
        </div>
        
        <div className="space-y-2 mb-4">
          {affiliate.features.slice(0, 2).map((feature, index) => (
            <div key={index} className="text-xs text-gray-600 flex items-center">
              <Users className="h-3 w-3 mr-2" />
              {feature}
            </div>
          ))}
        </div>
        
        <div className="text-xs text-gray-500 mb-4">
          Payment: {affiliate.paymentTerms}
        </div>
        
        <Button 
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          onClick={() => window.open(affiliate.joinUrl, '_blank')}
        >
          Join Program
          <ExternalLink className="h-4 w-4 ml-2" />
        </Button>
      </CardContent>
    </Card>
  );
};

export default AffiliateCard;