import React from 'react';
import DroneCard from './DroneCard';
import { Button } from '@/components/ui/button';
import { Filter, SortAsc, Target, Shield } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';

const DroneGrid: React.FC = () => {
  const { products } = useAppContext();

  return (
    <section className="py-16 bg-gradient-to-br from-black via-red-900 to-black">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
          <div>
            <h2 className="text-4xl font-bold text-white mb-2 flex items-center space-x-3">
              <Target className="h-8 w-8 text-red-400" />
              <span>Combat <span className="bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">Arsenal</span></span>
            </h2>
            <p className="text-red-200">Elite tactical drones for specialized operations</p>
            <div className="flex items-center space-x-4 mt-2 text-sm text-red-300">
              <div className="flex items-center space-x-1">
                <Shield className="h-4 w-4" />
                <span>CLASSIFIED</span>
              </div>
              <div className="bg-red-800 px-2 py-1 rounded text-xs">
                SECURITY CLEARANCE REQUIRED
              </div>
            </div>
          </div>
          
          <div className="flex gap-3 mt-4 lg:mt-0">
            <Button variant="outline" className="flex items-center gap-2 border-red-600 text-red-400 hover:bg-red-900">
              <Filter className="h-4 w-4" /> Filter Arsenal
            </Button>
            <Button variant="outline" className="flex items-center gap-2 border-red-600 text-red-400 hover:bg-red-900">
              <SortAsc className="h-4 w-4" /> Sort by Threat Level
            </Button>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <DroneCard key={product.id} product={product} />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button size="lg" className="px-8 py-3 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white">
            <Target className="mr-2 h-5 w-5" />
            Deploy Full Arsenal
          </Button>
        </div>
      </div>
    </section>
  );
};

export default DroneGrid;