import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Settings, Play, Pause, RotateCcw } from 'lucide-react';

interface AutomationRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  category: 'inventory' | 'orders' | 'marketing' | 'analytics';
  frequency: 'hourly' | 'daily' | 'weekly';
  lastRun?: Date;
  nextRun: Date;
  successRate: number;
}

const AITaskManager = () => {
  const [rules, setRules] = useState<AutomationRule[]>([
    {
      id: '1',
      name: 'Inventory Monitoring',
      description: 'Check stock levels and reorder when low',
      enabled: true,
      category: 'inventory',
      frequency: 'hourly',
      lastRun: new Date(Date.now() - 1800000),
      nextRun: new Date(Date.now() + 1800000),
      successRate: 98
    },
    {
      id: '2',
      name: 'Order Processing',
      description: 'Auto-process orders and send confirmations',
      enabled: true,
      category: 'orders',
      frequency: 'hourly',
      lastRun: new Date(Date.now() - 900000),
      nextRun: new Date(Date.now() + 2700000),
      successRate: 95
    },
    {
      id: '3',
      name: 'Performance Analytics',
      description: 'Generate daily performance reports',
      enabled: false,
      category: 'analytics',
      frequency: 'daily',
      nextRun: new Date(Date.now() + 86400000),
      successRate: 92
    },
    {
      id: '4',
      name: 'Marketing Campaigns',
      description: 'Auto-optimize ad campaigns and budgets',
      enabled: true,
      category: 'marketing',
      frequency: 'daily',
      lastRun: new Date(Date.now() - 43200000),
      nextRun: new Date(Date.now() + 43200000),
      successRate: 88
    }
  ]);

  const toggleRule = (id: string) => {
    setRules(prev => prev.map(rule => 
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ));
  };

  const runNow = (id: string) => {
    setRules(prev => prev.map(rule => 
      rule.id === id ? { 
        ...rule, 
        lastRun: new Date(),
        nextRun: new Date(Date.now() + getFrequencyMs(rule.frequency))
      } : rule
    ));
  };

  const getFrequencyMs = (frequency: string) => {
    switch (frequency) {
      case 'hourly': return 3600000;
      case 'daily': return 86400000;
      case 'weekly': return 604800000;
      default: return 3600000;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'inventory': return 'bg-blue-100 text-blue-800';
      case 'orders': return 'bg-green-100 text-green-800';
      case 'marketing': return 'bg-purple-100 text-purple-800';
      case 'analytics': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          AI Task Automation
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {rules.map((rule) => (
            <div key={rule.id} className="p-4 border rounded-lg">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium">{rule.name}</h4>
                    <Badge className={getCategoryColor(rule.category)}>
                      {rule.category}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{rule.description}</p>
                </div>
                <Switch
                  checked={rule.enabled}
                  onCheckedChange={() => toggleRule(rule.id)}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Frequency</p>
                  <p className="font-medium capitalize">{rule.frequency}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Success Rate</p>
                  <div className="flex items-center gap-2">
                    <Progress value={rule.successRate} className="flex-1" />
                    <span className="font-medium">{rule.successRate}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground">Last Run</p>
                  <p className="font-medium">
                    {rule.lastRun ? rule.lastRun.toLocaleTimeString() : 'Never'}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Next Run</p>
                  <p className="font-medium">{rule.nextRun.toLocaleTimeString()}</p>
                </div>
              </div>
              
              <div className="flex gap-2 mt-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => runNow(rule.id)}
                  disabled={!rule.enabled}
                >
                  <Play className="h-3 w-3 mr-1" />
                  Run Now
                </Button>
                <Button variant="outline" size="sm">
                  <RotateCcw className="h-3 w-3 mr-1" />
                  Reset
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default AITaskManager;