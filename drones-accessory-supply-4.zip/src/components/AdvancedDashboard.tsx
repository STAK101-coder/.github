import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PricingPlans from "./PricingPlans";
import AIPersonalTrainer from "./AIPersonalTrainer";
import SmartAutomation from "./SmartAutomation";
import PredictiveAnalytics from "./PredictiveAnalytics";
import { Crown, Zap, Brain, TrendingUp, Users, DollarSign, Target, Award } from "lucide-react";

const stats = [
  { label: "Active Users", value: "12,847", icon: Users, change: "+23%" },
  { label: "Monthly Revenue", value: "$2.4M", icon: DollarSign, change: "+18%" },
  { label: "Success Rate", value: "94.2%", icon: Target, change: "+5%" },
  { label: "AI Accuracy", value: "97.8%", icon: Brain, change: "+2%" }
];

export default function AdvancedDashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-black">
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <Crown className="w-8 h-8 text-red-500" />
            DRONE WARS Command Center
          </h1>
          <p className="text-gray-300">The world's most advanced dropshipping platform</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index} className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">{stat.label}</p>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                      <p className="text-green-400 text-sm">{stat.change}</p>
                    </div>
                    <IconComponent className="w-8 h-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="pricing" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800 border-gray-700">
            <TabsTrigger value="pricing" className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Pricing Plans
            </TabsTrigger>
            <TabsTrigger value="ai-trainer" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              AI Trainer
            </TabsTrigger>
            <TabsTrigger value="automation" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Automation
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pricing">
            <PricingPlans />
          </TabsContent>

          <TabsContent value="ai-trainer">
            <AIPersonalTrainer />
          </TabsContent>

          <TabsContent value="automation">
            <SmartAutomation />
          </TabsContent>

          <TabsContent value="analytics">
            <PredictiveAnalytics />
          </TabsContent>
        </Tabs>

        <Card className="mt-8 bg-gradient-to-r from-red-900 to-purple-900 border-red-500">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Award className="w-6 h-6" />
              What Makes Us Different
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-white">
              <div className="text-center">
                <Brain className="w-12 h-12 mx-auto mb-4 text-blue-400" />
                <h3 className="font-semibold mb-2">AI-Powered Everything</h3>
                <p className="text-sm text-gray-300">First platform with complete AI automation for pricing, inventory, and customer service</p>
              </div>
              <div className="text-center">
                <Target className="w-12 h-12 mx-auto mb-4 text-green-400" />
                <h3 className="font-semibold mb-2">Predictive Success</h3>
                <p className="text-sm text-gray-300">Advanced analytics predict market trends and optimize your business before competitors</p>
              </div>
              <div className="text-center">
                <Users className="w-12 h-12 mx-auto mb-4 text-purple-400" />
                <h3 className="font-semibold mb-2">Personal Business Coach</h3>
                <p className="text-sm text-gray-300">AI trainer provides personalized guidance from beginner to enterprise level</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}