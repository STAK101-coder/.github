import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Zap, Shield, ExternalLink, Copy, CheckCircle, AlertTriangle } from 'lucide-react';

const RateLimitingSetup: React.FC = () => {
  const [domain, setDomain] = useState('');
  const [setupStep, setSetupStep] = useState(1);
  const [cloudflareConnected, setCloudflareConnected] = useState(false);
  
  const rateLimitRules = [
    {
      name: 'API Endpoints',
      path: '/api/*',
      limit: '100 requests/minute',
      action: 'Block',
      priority: 'High'
    },
    {
      name: 'Login Attempts',
      path: '/auth/login',
      limit: '5 attempts/minute',
      action: 'Challenge',
      priority: 'Critical'
    },
    {
      name: 'General Pages',
      path: '/*',
      limit: '300 requests/minute',
      action: 'Challenge',
      priority: 'Medium'
    }
  ];
  
  const cloudflareSteps = [
    {
      title: 'Create Cloudflare Account',
      description: 'Sign up for free Cloudflare account',
      action: 'Visit cloudflare.com and create account'
    },
    {
      title: 'Add Your Website',
      description: 'Add your domain to Cloudflare',
      action: 'Click "Add a Site" and enter your domain'
    },
    {
      title: 'Update Nameservers',
      description: 'Point your domain to Cloudflare',
      action: 'Update DNS nameservers at your registrar'
    },
    {
      title: 'Configure Security',
      description: 'Set up rate limiting rules',
      action: 'Navigate to Security > WAF > Rate Limiting'
    }
  ];
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Zap className="h-6 w-6" />
          Rate Limiting & DDoS Protection
        </h2>
        <Badge variant="outline" className="text-orange-600 border-orange-600">
          Setup Required
        </Badge>
      </div>
      
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          Protect your platform from abuse and attacks with Cloudflare's free DDoS protection and rate limiting.
        </AlertDescription>
      </Alert>
      
      <Tabs defaultValue="setup" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="setup">Setup Guide</TabsTrigger>
          <TabsTrigger value="rules">Rate Limit Rules</TabsTrigger>
          <TabsTrigger value="monitor">Monitoring</TabsTrigger>
        </TabsList>
        
        <TabsContent value="setup" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cloudflare Setup (30 minutes)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="domain-input">Your Domain</Label>
                  <Input 
                    id="domain-input"
                    placeholder="yourdomain.com"
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                  />
                </div>
                
                <div className="space-y-4">
                  {cloudflareSteps.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-4 border rounded-lg">
                      <div className={`flex items-center justify-center w-6 h-6 rounded-full text-sm ${
                        setupStep > idx ? 'bg-green-600 text-white' : 
                        setupStep === idx + 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                      }`}>
                        {setupStep > idx ? <CheckCircle className="h-3 w-3" /> : idx + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold">{step.title}</h4>
                        <p className="text-sm text-gray-600 mb-2">{step.description}</p>
                        <p className="text-xs bg-gray-100 p-2 rounded font-mono">{step.action}</p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    onClick={() => setSetupStep(Math.min(setupStep + 1, cloudflareSteps.length))}
                    disabled={setupStep >= cloudflareSteps.length}
                  >
                    {setupStep >= cloudflareSteps.length ? 'Setup Complete' : 'Next Step'}
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => window.open('https://cloudflare.com', '_blank')}
                  >
                    Open Cloudflare <ExternalLink className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="rules" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recommended Rate Limiting Rules</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {rateLimitRules.map((rule, idx) => (
                  <div key={idx} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">{rule.name}</h4>
                      <Badge variant="outline" className={`${
                        rule.priority === 'Critical' ? 'text-red-600 border-red-600' :
                        rule.priority === 'High' ? 'text-orange-600 border-orange-600' :
                        'text-blue-600 border-blue-600'
                      }`}>
                        {rule.priority}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                      <div>
                        <span className="text-gray-500">Path:</span>
                        <code className="ml-1 bg-gray-100 px-1 rounded">{rule.path}</code>
                      </div>
                      <div>
                        <span className="text-gray-500">Limit:</span>
                        <span className="ml-1 font-medium">{rule.limit}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Action:</span>
                        <span className="ml-1 font-medium">{rule.action}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Configure these rules in Cloudflare Dashboard → Security → WAF → Rate Limiting Rules
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Cloudflare Rule Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">API Protection Rule</h4>
                  <div className="space-y-2 text-sm font-mono">
                    <div className="flex items-center gap-2">
                      <span>Rule Name:</span>
                      <code className="bg-white p-1 rounded">API Rate Limit</code>
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard('API Rate Limit')}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Expression:</span>
                      <code className="bg-white p-1 rounded">(http.request.uri.path contains "/api/")</code>
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard('(http.request.uri.path contains "/api/")')}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div>Rate: 100 requests per minute</div>
                    <div>Action: Block</div>
                  </div>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Login Protection Rule</h4>
                  <div className="space-y-2 text-sm font-mono">
                    <div className="flex items-center gap-2">
                      <span>Rule Name:</span>
                      <code className="bg-white p-1 rounded">Login Rate Limit</code>
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard('Login Rate Limit')}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Expression:</span>
                      <code className="bg-white p-1 rounded">(http.request.uri.path contains "/auth/")</code>
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard('(http.request.uri.path contains "/auth/")')}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div>Rate: 5 requests per minute</div>
                    <div>Action: JS Challenge</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="monitor" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Rate Limiting Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-red-600">0</div>
                  <div className="text-sm text-gray-600">Blocked Requests</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">0</div>
                  <div className="text-sm text-gray-600">Challenged Requests</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-green-600">0</div>
                  <div className="text-sm text-gray-600">Allowed Requests</div>
                </div>
              </div>
              
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Statistics will appear here once Cloudflare is configured and receiving traffic.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RateLimitingSetup;