import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, Lock, Eye, AlertTriangle, CheckCircle, Key, Database, CreditCard } from 'lucide-react';

const SecurityDashboard: React.FC = () => {
  const securityMetrics = {
    threatLevel: 'Low',
    encryptionStatus: 'Active',
    lastSecurityScan: '2 hours ago',
    vulnerabilities: 0,
    activeConnections: 1247,
    blockedAttempts: 23
  };

  const securityFeatures = [
    {
      icon: <Lock className="h-5 w-5" />,
      title: 'SSL/TLS Encryption',
      status: 'Active',
      description: 'End-to-end encryption for all data transmission'
    },
    {
      icon: <Database className="h-5 w-5" />,
      title: 'Database Security',
      status: 'Protected',
      description: 'Row-level security and encrypted storage'
    },
    {
      icon: <CreditCard className="h-5 w-5" />,
      title: 'Payment Security',
      status: 'PCI Compliant',
      description: 'Secure payment processing with tokenization'
    },
    {
      icon: <Key className="h-5 w-5" />,
      title: 'Authentication',
      status: 'Multi-Factor',
      description: 'Advanced user authentication and authorization'
    }
  ];

  const recentAlerts = [
    {
      type: 'info',
      message: 'Security scan completed successfully',
      time: '2 hours ago'
    },
    {
      type: 'warning',
      message: 'Unusual login pattern detected and blocked',
      time: '6 hours ago'
    },
    {
      type: 'success',
      message: 'SSL certificate renewed automatically',
      time: '1 day ago'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="h-6 w-6" />
          Security Dashboard
        </h2>
        <Badge variant="outline" className="text-green-600 border-green-600">
          System Secure
        </Badge>
      </div>

      {/* Security Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Threat Level</p>
                <p className="text-2xl font-bold text-green-600">{securityMetrics.threatLevel}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Connections</p>
                <p className="text-2xl font-bold">{securityMetrics.activeConnections}</p>
              </div>
              <Eye className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Blocked Attempts</p>
                <p className="text-2xl font-bold text-red-600">{securityMetrics.blockedAttempts}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Features */}
      <Card>
        <CardHeader>
          <CardTitle>Security Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {securityFeatures.map((feature, index) => (
              <div key={index} className="flex items-start gap-3 p-4 border rounded-lg">
                <div className="text-blue-600">{feature.icon}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold">{feature.title}</h4>
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      {feature.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Security Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Security Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentAlerts.map((alert, index) => (
              <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                <div className={`mt-1 ${
                  alert.type === 'success' ? 'text-green-600' :
                  alert.type === 'warning' ? 'text-yellow-600' :
                  'text-blue-600'
                }`}>
                  {alert.type === 'success' ? <CheckCircle className="h-4 w-4" /> :
                   alert.type === 'warning' ? <AlertTriangle className="h-4 w-4" /> :
                   <Shield className="h-4 w-4" />}
                </div>
                <div className="flex-1">
                  <p className="text-sm">{alert.message}</p>
                  <p className="text-xs text-gray-500">{alert.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Security Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Security Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Shield className="h-6 w-6" />
              Run Security Scan
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Lock className="h-6 w-6" />
              Update Certificates
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2">
              <Eye className="h-6 w-6" />
              View Audit Logs
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityDashboard;