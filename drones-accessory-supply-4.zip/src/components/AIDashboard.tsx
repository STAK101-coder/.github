import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bot, Brain, Zap, CheckCircle } from 'lucide-react';
import AIAssistant from './AIAssistant';

const AIDashboard = () => {
  const aiStats = {
    tasksCompleted: 1247,
    timeSaved: '23.5 hours',
    efficiency: 94,
    activeTasks: 8
  };

  const automationRules = [
    { name: 'Inventory Monitoring', status: 'active', lastRun: '2 min ago' },
    { name: 'Order Processing', status: 'active', lastRun: '5 min ago' },
    { name: 'Marketing Optimization', status: 'active', lastRun: '1 hour ago' }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-full">
                <Brain className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <CardTitle>AI Assistant Status</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Automated business management system
                </p>
              </div>
            </div>
            <Badge className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              Active
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{aiStats.tasksCompleted}</div>
              <p className="text-sm text-muted-foreground">Tasks Completed</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{aiStats.timeSaved}</div>
              <p className="text-sm text-muted-foreground">Time Saved</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{aiStats.efficiency}%</div>
              <p className="text-sm text-muted-foreground">Efficiency</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{aiStats.activeTasks}</div>
              <p className="text-sm text-muted-foreground">Active Tasks</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AIAssistant />
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Active Automations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {automationRules.map((rule, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{rule.name}</p>
                    <p className="text-sm text-muted-foreground">Last run: {rule.lastRun}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <Badge variant="default">{rule.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AIDashboard;