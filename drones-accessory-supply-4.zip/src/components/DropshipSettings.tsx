import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Truck, Package, DollarSign, Users, Settings } from 'lucide-react';

interface SupplierDropship {
  id: string;
  name: string;
  enabled: boolean;
  commission: number;
  autoFulfill: boolean;
  shippingZones: string[];
}

const DropshipSettings: React.FC = () => {
  const [suppliers, setSuppliers] = useState<SupplierDropship[]>([
    {
      id: '1',
      name: 'SkyTech Solutions',
      enabled: true,
      commission: 15,
      autoFulfill: true,
      shippingZones: ['US', 'CA', 'EU']
    },
    {
      id: '2',
      name: 'DroneWorld Express',
      enabled: true,
      commission: 12,
      autoFulfill: false,
      shippingZones: ['US', 'MX']
    },
    {
      id: '3',
      name: 'AerialPro Distributors',
      enabled: false,
      commission: 18,
      autoFulfill: true,
      shippingZones: ['US', 'CA']
    }
  ]);

  const toggleSupplier = (id: string) => {
    setSuppliers(suppliers.map(supplier => 
      supplier.id === id 
        ? { ...supplier, enabled: !supplier.enabled }
        : supplier
    ));
  };

  const toggleAutoFulfill = (id: string) => {
    setSuppliers(suppliers.map(supplier => 
      supplier.id === id 
        ? { ...supplier, autoFulfill: !supplier.autoFulfill }
        : supplier
    ));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Dropshipping Configuration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-medium text-blue-900 mb-2">How Dropshipping Works</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Customer places order on your Shopify store</li>
                <li>• Order details automatically sent to supplier</li>
                <li>• Supplier ships directly to customer</li>
                <li>• You earn commission without handling inventory</li>
              </ul>
            </div>
            
            {suppliers.map((supplier) => (
              <Card key={supplier.id} className="border">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-semibold">{supplier.name}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <DollarSign className="h-3 w-3" />
                        <span className="text-sm text-gray-600">{supplier.commission}% commission</span>
                      </div>
                    </div>
                    <Switch 
                      checked={supplier.enabled} 
                      onCheckedChange={() => toggleSupplier(supplier.id)}
                    />
                  </div>
                  
                  {supplier.enabled && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Package className="h-4 w-4" />
                          <span className="text-sm">Auto-fulfill orders</span>
                        </div>
                        <Switch 
                          checked={supplier.autoFulfill} 
                          onCheckedChange={() => toggleAutoFulfill(supplier.id)}
                        />
                      </div>
                      
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Users className="h-4 w-4" />
                          <span className="text-sm font-medium">Shipping Zones</span>
                        </div>
                        <div className="flex gap-1">
                          {supplier.shippingZones.map((zone) => (
                            <Badge key={zone} variant="outline" className="text-xs">
                              {zone}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
            
            <Button className="w-full mt-4">
              <Settings className="h-4 w-4 mr-2" />
              Configure Webhook Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DropshipSettings;