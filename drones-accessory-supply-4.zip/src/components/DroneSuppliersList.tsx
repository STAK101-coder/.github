import React, { useState } from 'react';
import SupplierCard from './SupplierCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter } from 'lucide-react';

const droneSuppliers = [
  {
    id: '1',
    name: 'SkyTech Solutions',
    location: 'California, USA',
    rating: 4.9,
    reviews: 1247,
    specialties: ['DJI Products', 'Professional Drones', 'Accessories'],
    verified: true,
    yearsActive: 8,
    logo: '🏢',
    minOrder: '$500',
    paymentTerms: 'Net 30',
    shippingTime: '2-5 days',
    contact: { phone: '+1-555-0123', email: 'sales@skytech.com' }
  },
  {
    id: '2',
    name: 'DroneWorld Express',
    location: 'Texas, USA',
    rating: 4.7,
    reviews: 892,
    specialties: ['Racing Drones', 'FPV Equipment', 'Custom Builds'],
    verified: true,
    yearsActive: 5,
    logo: '🌟',
    minOrder: '$250',
    shippingTime: '1-3 days',
    contact: { phone: '+1-555-0456', email: 'info@droneworld.com' }
  },
  {
    id: '3',
    name: 'AerialPro Distributors',
    location: 'New York, USA',
    rating: 4.8,
    reviews: 634,
    specialties: ['Commercial Drones', 'Industrial Solutions', 'Training'],
    verified: true,
    yearsActive: 12,
    logo: '🚀',
    minOrder: '$1000',
    paymentTerms: 'Net 15',
    shippingTime: '3-7 days',
    contact: { email: 'contact@aerialpro.com' }
  },
  {
    id: '4',
    name: 'Global Drone Supply',
    location: 'International',
    rating: 4.6,
    reviews: 2156,
    specialties: ['Wholesale', 'Bulk Orders', 'OEM Parts'],
    verified: true,
    yearsActive: 15,
    logo: '🌍',
    minOrder: '$2000',
    paymentTerms: 'LC/TT',
    shippingTime: '7-14 days',
    contact: { phone: '+86-138-0013-8000', email: 'global@dronesupply.com' }
  },
  {
    id: '5',
    name: 'TechWing Innovations',
    location: 'Florida, USA',
    rating: 4.5,
    reviews: 423,
    specialties: ['Camera Drones', 'Gimbal Systems', 'Batteries'],
    verified: true,
    yearsActive: 6,
    logo: '⚡',
    minOrder: '$300',
    shippingTime: '2-4 days',
    contact: { phone: '+1-555-0789', email: 'sales@techwing.com' }
  },
  {
    id: '6',
    name: 'European Drone Hub',
    location: 'Germany, EU',
    rating: 4.4,
    reviews: 567,
    specialties: ['EU Compliance', 'Agricultural Drones', 'Mapping'],
    verified: true,
    yearsActive: 9,
    logo: '🇪🇺',
    minOrder: '€400',
    paymentTerms: 'SEPA',
    shippingTime: '3-6 days',
    contact: { email: 'eu@dronehub.de' }
  }
];

const DroneSuppliersList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('all');
  const [specialtyFilter, setSpecialtyFilter] = useState('all');

  const filteredSuppliers = droneSuppliers.filter(supplier => {
    const matchesSearch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         supplier.specialties.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesLocation = locationFilter === 'all' || supplier.location.includes(locationFilter);
    const matchesSpecialty = specialtyFilter === 'all' || 
                            supplier.specialties.some(s => s.toLowerCase().includes(specialtyFilter.toLowerCase()));
    
    return matchesSearch && matchesLocation && matchesSpecialty;
  });

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Drone <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">Suppliers</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Connect with verified drone suppliers worldwide for the best deals and authentic products
          </p>
        </div>
        
        {/* Search and Filter Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 max-w-4xl mx-auto">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search suppliers or specialties..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={locationFilter} onValueChange={setLocationFilter}>
            <SelectTrigger className="w-full md:w-48">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="USA">USA</SelectItem>
              <SelectItem value="International">International</SelectItem>
              <SelectItem value="EU">Europe</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Specialty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Specialties</SelectItem>
              <SelectItem value="professional">Professional</SelectItem>
              <SelectItem value="racing">Racing/FPV</SelectItem>
              <SelectItem value="commercial">Commercial</SelectItem>
              <SelectItem value="wholesale">Wholesale</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredSuppliers.map((supplier) => (
            <SupplierCard key={supplier.id} supplier={supplier} />
          ))}
        </div>
        
        {filteredSuppliers.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No suppliers found matching your criteria.</p>
            <Button 
              onClick={() => {
                setSearchTerm('');
                setLocationFilter('all');
                setSpecialtyFilter('all');
              }}
              variant="outline"
              className="mt-4"
            >
              Clear Filters
            </Button>
          </div>
        )}
        
        <div className="text-center">
          <Button size="lg" variant="outline" className="px-8 py-3">
            Request New Supplier
          </Button>
        </div>
      </div>
    </section>
  );
};

export default DroneSuppliersList;