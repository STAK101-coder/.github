import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { BarChart3, Package, ShoppingBag, TrendingUp, Settings, Users, Eye, DollarSign } from 'lucide-react';

const QuickAccessPanel: React.FC = () => {
  const navigate = useNavigate();

  const quickActions = [
    {
      title: 'Owner Dashboard',
      description: 'View performance, traffic & analytics',
      icon: BarChart3,
      path: '/owner',
      color: 'bg-blue-500'
    },
    {
      title: 'Admin Panel',
      description: 'Manage products, orders & settings',
      icon: Settings,
      path: '/admin',
      color: 'bg-purple-500'
    },
    {
      title: 'Marketing Hub',
      description: 'SEO, social media & campaigns',
      icon: TrendingUp,
      path: '/marketing',
      color: 'bg-green-500'
    },
    {
      title: 'Shopify Store',
      description: 'Manage your online store',
      icon: ShoppingBag,
      path: '/shopify',
      color: 'bg-orange-500'
    },
    {
      title: 'Inventory',
      description: 'Stock levels & suppliers',
      icon: Package,
      path: '/inventory',
      color: 'bg-red-500'
    }
  ];

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Quick Access - Business Management
          </CardTitle>
          <p className="text-sm text-gray-600">
            Access all your business tools and dashboards from one place
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quickActions.map((action, index) => {
              const IconComponent = action.icon;
              return (
                <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(action.path)}>
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className={`${action.color} p-2 rounded-lg`}>
                        <IconComponent className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-sm">{action.title}</h3>
                        <p className="text-xs text-gray-500 mt-1">{action.description}</p>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="mt-2 w-full"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(action.path);
                          }}
                        >
                          Access
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Owner Quick Tips:</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Check your Owner Dashboard daily for performance metrics</li>
              <li>• Monitor inventory levels to avoid stockouts</li>
              <li>• Review marketing campaigns for ROI optimization</li>
              <li>• Track Shopify orders and fulfillment status</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QuickAccessPanel;