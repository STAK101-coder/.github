import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TrafficGenerationDashboard from "./TrafficGenerationDashboard";
import SEOOptimization from "./SEOOptimization";
import SocialMediaManager from "./SocialMediaManager";
import MarketingCampaigns from "./MarketingCampaigns";
import { TrendingUp, Search, Share2, Target } from "lucide-react";

const MarketingDashboard = () => {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-4xl font-bold mb-2">Marketing Dashboard</h1>
        <p className="text-gray-600">Drive traffic and grow your drone dropshipping business</p>
      </div>

      <Tabs defaultValue="traffic" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="traffic" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Traffic Generation
          </TabsTrigger>
          <TabsTrigger value="seo" className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            SEO Optimization
          </TabsTrigger>
          <TabsTrigger value="social" className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Social Media
          </TabsTrigger>
          <TabsTrigger value="campaigns" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Campaigns
          </TabsTrigger>
        </TabsList>

        <TabsContent value="traffic">
          <TrafficGenerationDashboard />
        </TabsContent>

        <TabsContent value="seo">
          <SEOOptimization />
        </TabsContent>

        <TabsContent value="social">
          <SocialMediaManager />
        </TabsContent>

        <TabsContent value="campaigns">
          <MarketingCampaigns />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MarketingDashboard;