import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Target, DollarSign, Users, TrendingUp, Play, Pause, Edit } from "lucide-react";

const MarketingCampaigns = () => {
  const activeCampaigns = [
    {
      name: "Holiday Drone Sale",
      platform: "Google Ads",
      budget: 2500,
      spent: 1850,
      clicks: 3420,
      conversions: 89,
      status: "active",
      roi: 340
    },
    {
      name: "Professional Photography",
      platform: "Facebook",
      budget: 1800,
      spent: 1200,
      clicks: 2150,
      conversions: 52,
      status: "active",
      roi: 280
    },
    {
      name: "Beginner Drone Bundle",
      platform: "Instagram",
      budget: 1200,
      spent: 980,
      clicks: 1890,
      conversions: 34,
      status: "paused",
      roi: 190
    }
  ];

  const campaignTemplates = [
    {
      name: "Black Friday Sale",
      description: "High-converting seasonal campaign",
      platforms: ["Google", "Facebook", "Instagram"],
      estimatedROI: "300-400%"
    },
    {
      name: "New Product Launch",
      description: "Generate buzz for new drone models",
      platforms: ["YouTube", "TikTok", "Instagram"],
      estimatedROI: "200-300%"
    },
    {
      name: "Retargeting Campaign",
      description: "Re-engage website visitors",
      platforms: ["Facebook", "Google"],
      estimatedROI: "400-500%"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-500";
      case "paused": return "bg-yellow-500";
      case "ended": return "bg-gray-500";
      default: return "bg-blue-500";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">Marketing Campaigns</h2>
        <Button className="bg-orange-600 hover:bg-orange-700">
          <Target className="mr-2 h-4 w-4" />
          Create Campaign
        </Button>
      </div>

      {/* Campaign Performance Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Total Spent</p>
                <p className="text-2xl font-bold">$4,030</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Clicks</p>
                <p className="text-2xl font-bold">7,460</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Conversions</p>
                <p className="text-2xl font-bold">175</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Avg ROI</p>
                <p className="text-2xl font-bold">270%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Campaigns */}
      <Card>
        <CardHeader>
          <CardTitle>Active Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activeCampaigns.map((campaign, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold">{campaign.name}</h3>
                    <Badge className={getStatusColor(campaign.status)}>
                      {campaign.status}
                    </Badge>
                    <Badge variant="outline">{campaign.platform}</Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      {campaign.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-5 gap-4 mb-3">
                  <div>
                    <p className="text-sm text-gray-600">Budget</p>
                    <p className="font-medium">${campaign.budget}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Spent</p>
                    <p className="font-medium">${campaign.spent}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Clicks</p>
                    <p className="font-medium">{campaign.clicks.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Conversions</p>
                    <p className="font-medium">{campaign.conversions}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">ROI</p>
                    <p className="font-medium text-green-600">{campaign.roi}%</p>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Budget Used</span>
                    <span>{Math.round((campaign.spent / campaign.budget) * 100)}%</span>
                  </div>
                  <Progress value={(campaign.spent / campaign.budget) * 100} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Campaign Templates */}
      <Card>
        <CardHeader>
          <CardTitle>Campaign Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            {campaignTemplates.map((template, index) => (
              <div key={index} className="p-4 border rounded-lg hover:bg-gray-50">
                <h3 className="font-semibold mb-2">{template.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {template.platforms.map((platform, pIndex) => (
                    <Badge key={pIndex} variant="outline" className="text-xs">
                      {platform}
                    </Badge>
                  ))}
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-green-600">
                    ROI: {template.estimatedROI}
                  </span>
                  <Button size="sm">
                    Use Template
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MarketingCampaigns;