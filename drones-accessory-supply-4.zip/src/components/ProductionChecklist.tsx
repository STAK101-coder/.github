import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, Circle, Rocket, AlertTriangle } from 'lucide-react';

interface ChecklistItem {
  id: string;
  category: string;
  task: string;
  priority: 'high' | 'medium' | 'low';
  description: string;
  completed: boolean;
}

const ProductionChecklist: React.FC = () => {
  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    {
      id: '1',
      category: 'Security',
      task: 'Configure SSL Certificate',
      priority: 'high',
      description: 'Enable HTTPS for secure data transmission',
      completed: false
    },
    {
      id: '2',
      category: 'Security',
      task: 'Set up Rate Limiting',
      priority: 'high',
      description: 'Prevent API abuse and DDoS attacks',
      completed: false
    },
    {
      id: '3',
      category: 'Performance',
      task: 'Enable CDN',
      priority: 'medium',
      description: 'Improve loading speeds globally',
      completed: false
    },
    {
      id: '4',
      category: 'SEO',
      task: 'Add Meta Tags',
      priority: 'medium',
      description: 'Optimize for search engines',
      completed: true
    },
    {
      id: '5',
      category: 'Analytics',
      task: 'Setup Google Analytics',
      priority: 'medium',
      description: 'Track user behavior and conversions',
      completed: false
    },
    {
      id: '6',
      category: 'Legal',
      task: 'Privacy Policy',
      priority: 'high',
      description: 'GDPR compliance documentation',
      completed: true
    },
    {
      id: '7',
      category: 'Legal',
      task: 'Terms of Service',
      priority: 'high',
      description: 'User agreement and liability terms',
      completed: true
    },
    {
      id: '8',
      category: 'Testing',
      task: 'Cross-browser Testing',
      priority: 'medium',
      description: 'Ensure compatibility across browsers',
      completed: false
    },
    {
      id: '9',
      category: 'Backup',
      task: 'Database Backup Strategy',
      priority: 'high',
      description: 'Automated daily backups',
      completed: true
    },
    {
      id: '10',
      category: 'Monitoring',
      task: 'Error Tracking',
      priority: 'medium',
      description: 'Real-time error monitoring',
      completed: false
    }
  ]);

  const toggleItem = (id: string) => {
    setChecklist(prev => 
      prev.map(item => 
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  const getPriorityBadge = (priority: string) => {
    const variants = {
      high: 'bg-red-100 text-red-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    return <Badge className={variants[priority as keyof typeof variants]}>{priority.toUpperCase()}</Badge>;
  };

  const completedCount = checklist.filter(item => item.completed).length;
  const totalCount = checklist.length;
  const completionPercentage = Math.round((completedCount / totalCount) * 100);

  const groupedChecklist = checklist.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, ChecklistItem[]>);

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold flex items-center justify-center space-x-2">
          <Rocket className="h-6 w-6" />
          <span>Production Launch Checklist</span>
        </h2>
        <div className="flex justify-center items-center space-x-4">
          <div className="text-3xl font-bold text-blue-600">{completionPercentage}%</div>
          <div className="text-sm text-gray-600">Complete ({completedCount}/{totalCount})</div>
        </div>
        {completionPercentage >= 80 ? (
          <Badge className="bg-green-100 text-green-800">Ready for Launch</Badge>
        ) : (
          <Badge className="bg-yellow-100 text-yellow-800">Preparation Needed</Badge>
        )}
      </div>

      <div className="space-y-4">
        {Object.entries(groupedChecklist).map(([category, items]) => (
          <Card key={category}>
            <CardHeader>
              <CardTitle>{category}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <Checkbox
                      checked={item.completed}
                      onCheckedChange={() => toggleItem(item.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className={`font-medium ${item.completed ? 'line-through text-gray-500' : ''}`}>
                          {item.task}
                        </h3>
                        {getPriorityBadge(item.priority)}
                      </div>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                    {item.completed ? (
                      <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-400 mt-1" />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {completionPercentage < 80 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2 text-yellow-800">
              <AlertTriangle className="h-5 w-5" />
              <p className="font-medium">Complete high-priority items before launching to production.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ProductionChecklist;