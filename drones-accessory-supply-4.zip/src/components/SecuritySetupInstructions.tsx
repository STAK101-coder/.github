import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, Zap, CheckCircle, ExternalLink } from 'lucide-react';

const SecuritySetupInstructions: React.FC = () => {
  return (
    <div className="space-y-6">
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          Follow these steps to secure your platform with SSL certificates and rate limiting.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              SSL Certificate Setup (15 minutes)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Badge className="bg-blue-100 text-blue-800">1</Badge>
                <div>
                  <h4 className="font-semibold">Deploy to Vercel/Netlify</h4>
                  <p className="text-sm text-gray-600">These platforms provide automatic SSL certificates</p>
                  <p className="text-xs text-gray-500 mt-1">• Connect GitHub → Deploy → SSL enabled automatically</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Badge className="bg-blue-100 text-blue-800">2</Badge>
                <div>
                  <h4 className="font-semibold">Add Custom Domain</h4>
                  <p className="text-sm text-gray-600">Purchase domain and add to hosting platform</p>
                  <p className="text-xs text-gray-500 mt-1">• Domain settings → Add domain → SSL auto-provisioned</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Badge className="bg-green-100 text-green-800">✓</Badge>
                <div>
                  <h4 className="font-semibold">Verify SSL</h4>
                  <p className="text-sm text-gray-600">Check for padlock icon in browser address bar</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Rate Limiting Setup (30 minutes)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Badge className="bg-orange-100 text-orange-800">1</Badge>
                <div>
                  <h4 className="font-semibold">Sign up for Cloudflare</h4>
                  <p className="text-sm text-gray-600">Free plan includes DDoS protection and rate limiting</p>
                  <a href="https://cloudflare.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 text-xs flex items-center gap-1 mt-1">
                    cloudflare.com <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Badge className="bg-orange-100 text-orange-800">2</Badge>
                <div>
                  <h4 className="font-semibold">Add Domain to Cloudflare</h4>
                  <p className="text-sm text-gray-600">Follow setup wizard to add your domain</p>
                  <p className="text-xs text-gray-500 mt-1">• Add site → Enter domain → Update nameservers</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Badge className="bg-orange-100 text-orange-800">3</Badge>
                <div>
                  <h4 className="font-semibold">Configure Security Rules</h4>
                  <p className="text-sm text-gray-600">Set up rate limiting in Cloudflare dashboard</p>
                  <div className="text-xs text-gray-500 mt-1 space-y-1">
                    <p>• Security → WAF → Rate Limiting Rules</p>
                    <p>• API endpoints: 100 requests/minute</p>
                    <p>• Login pages: 5 attempts/minute</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Verification</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="font-semibold text-green-600">SSL Check</h4>
                <div className="text-sm space-y-1">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>Padlock icon in browser</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-600" />
                    <span>URL starts with https://</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-semibold text-blue-600">Rate Limit Check</h4>
                <div className="text-sm space-y-1">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-blue-600" />
                    <span>Cloudflare dashboard active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-blue-600" />
                    <span>Security rules configured</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SecuritySetupInstructions;