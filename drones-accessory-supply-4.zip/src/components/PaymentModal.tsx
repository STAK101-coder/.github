import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PaymentSecurity from './PaymentSecurity';
import { CheckCircle } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: {
    name: string;
    price: number;
  };
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, product }) => {
  const [paymentComplete, setPaymentComplete] = useState(false);

  const handlePaymentSubmit = (paymentData: any) => {
    console.log('Payment processed:', paymentData);
    setPaymentComplete(true);
    setTimeout(() => {
      setPaymentComplete(false);
      onClose();
    }, 3000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {paymentComplete ? 'Payment Successful!' : `Purchase ${product.name}`}
          </DialogTitle>
        </DialogHeader>
        
        {paymentComplete ? (
          <div className="text-center py-8">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Thank you for your purchase!</h3>
            <p className="text-gray-600">Your order has been processed securely.</p>
          </div>
        ) : (
          <PaymentSecurity 
            onPaymentSubmit={handlePaymentSubmit}
            amount={product.price}
          />
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;