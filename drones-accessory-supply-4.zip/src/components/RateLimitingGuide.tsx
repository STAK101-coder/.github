import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Zap, Code, Server, Copy, AlertTriangle } from 'lucide-react';

const RateLimitingGuide: React.FC = () => {
  const [copiedText, setCopiedText] = useState('');

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(''), 2000);
  };

  const cloudflareCode = `// Cloudflare Worker Rate Limiting
export default {
  async fetch(request, env) {
    const ip = request.headers.get('CF-Connecting-IP');
    const key = \`rate_limit:\${ip}\`;
    
    // Check current count
    const current = await env.KV.get(key);
    const count = current ? parseInt(current) : 0;
    
    if (count >= 100) { // 100 requests per hour
      return new Response('Rate limit exceeded', { status: 429 });
    }
    
    // Increment counter
    await env.KV.put(key, (count + 1).toString(), { expirationTtl: 3600 });
    
    return fetch(request);
  }
};`;

  const supabaseEdgeFunction = `export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const clientIP = req.headers.get('x-forwarded-for') || 'unknown';
  const rateLimitKey = \`rate_limit_\${clientIP}\`;
  
  // Check rate limit (implement with Supabase or Redis)
  const currentCount = await checkRateLimit(rateLimitKey);
  
  if (currentCount > 60) { // 60 requests per minute
    return new Response(
      JSON.stringify({ error: 'Rate limit exceeded' }),
      { 
        status: 429, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
  
  // Process request
  const data = { message: 'Request processed successfully' };
  return new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
});`;

  const nginxConfig = `# Nginx Rate Limiting Configuration
http {
    # Define rate limiting zones
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=1r/s;
    
    server {
        listen 443 ssl;
        server_name yourdomain.com;
        
        # API endpoints rate limiting
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://backend;
        }
        
        # Login endpoint strict limiting
        location /auth/login {
            limit_req zone=login burst=5 nodelay;
            proxy_pass http://backend;
        }
    }
}`;

  const rateLimitStrategies = [
    {
      method: 'Cloudflare',
      difficulty: 'Easy',
      cost: 'Free/Paid',
      features: ['DDoS protection', 'Global CDN', 'Web Application Firewall', 'Bot management'],
      setup: 'Add domain to Cloudflare, update nameservers, configure security rules'
    },
    {
      method: 'Supabase Edge Functions',
      difficulty: 'Medium',
      cost: 'Free tier available',
      features: ['Custom logic', 'Database integration', 'Real-time monitoring', 'Flexible rules'],
      setup: 'Create edge function with rate limiting logic, deploy to Supabase'
    },
    {
      method: 'Nginx/Apache',
      difficulty: 'Advanced',
      cost: 'Server costs',
      features: ['Full control', 'High performance', 'Custom configurations', 'Server-level protection'],
      setup: 'Configure web server with rate limiting modules and rules'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Zap className="h-6 w-6" />
          Rate Limiting Implementation Guide
        </h2>
        <Badge variant="outline" className="text-orange-600 border-orange-600">
          DDoS Protection
        </Badge>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Rate limiting prevents abuse by limiting the number of requests from a single IP address or user within a specific time window.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="strategies" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="strategies">Strategies</TabsTrigger>
          <TabsTrigger value="cloudflare">Cloudflare</TabsTrigger>
          <TabsTrigger value="supabase">Supabase</TabsTrigger>
          <TabsTrigger value="server">Server Config</TabsTrigger>
        </TabsList>

        <TabsContent value="strategies" className="space-y-4">
          <div className="grid gap-4">
            {rateLimitStrategies.map((strategy, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      {strategy.method}
                      <Badge variant="outline" className={
                        strategy.difficulty === 'Easy' ? 'text-green-600 border-green-600' :
                        strategy.difficulty === 'Medium' ? 'text-yellow-600 border-yellow-600' :
                        'text-red-600 border-red-600'
                      }>
                        {strategy.difficulty}
                      </Badge>
                    </CardTitle>
                    <Badge variant="secondary">{strategy.cost}</Badge>
                  </div>
                  <p className="text-sm text-gray-600">{strategy.setup}</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {strategy.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center gap-2 text-sm">
                        <Shield className="h-3 w-3 text-green-600" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="cloudflare" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cloudflare Rate Limiting (Recommended)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold">Step 1: Add Domain to Cloudflare</h4>
                <ol className="text-sm space-y-1 ml-4">
                  <li>1. Sign up at cloudflare.com</li>
                  <li>2. Add your domain</li>
                  <li>3. Update nameservers at your registrar</li>
                  <li>4. Wait for DNS propagation (24-48 hours)</li>
                </ol>
                
                <h4 className="font-semibold">Step 2: Configure Security Rules</h4>
                <div className="bg-gray-50 p-3 rounded border space-y-2">
                  <p className="text-sm font-medium">Security → WAF → Rate Limiting Rules</p>
                  <p className="text-sm">• API endpoints: 100 requests/minute</p>
                  <p className="text-sm">• Login pages: 5 attempts/minute</p>
                  <p className="text-sm">• General pages: 300 requests/minute</p>
                </div>
                
                <h4 className="font-semibold">Step 3: Advanced Protection</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="border rounded p-3">
                    <h5 className="font-medium">DDoS Protection</h5>
                    <p className="text-sm text-gray-600">Automatic protection against volumetric attacks</p>
                  </div>
                  <div className="border rounded p-3">
                    <h5 className="font-medium">Bot Management</h5>
                    <p className="text-sm text-gray-600">Block malicious bots and scrapers</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="supabase" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Supabase Edge Function Rate Limiting</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold">Create Rate Limiting Edge Function</h4>
                <div className="relative">
                  <pre className="bg-gray-900 text-gray-100 p-4 rounded text-xs overflow-x-auto">
                    <code>{supabaseEdgeFunction}</code>
                  </pre>
                  <Button
                    size="sm"
                    variant="outline"
                    className="absolute top-2 right-2"
                    onClick={() => copyToClipboard(supabaseEdgeFunction, 'Supabase function')}
                  >
                    <Copy className="h-3 w-3" />
                    {copiedText === 'Supabase function' ? 'Copied!' : 'Copy'}
                  </Button>
                </div>
                
                <h4 className="font-semibold">Implementation Steps</h4>
                <ol className="text-sm space-y-1 ml-4">
                  <li>1. Create new edge function in Supabase dashboard</li>
                  <li>2. Paste the rate limiting code above</li>
                  <li>3. Deploy the function</li>
                  <li>4. Update your API calls to use the function endpoint</li>
                  <li>5. Monitor usage in Supabase logs</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="server" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Server-Level Rate Limiting</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold">Nginx Configuration</h4>
                <div className="relative">
                  <pre className="bg-gray-900 text-gray-100 p-4 rounded text-xs overflow-x-auto">
                    <code>{nginxConfig}</code>
                  </pre>
                  <Button
                    size="sm"
                    variant="outline"
                    className="absolute top-2 right-2"
                    onClick={() => copyToClipboard(nginxConfig, 'Nginx config')}
                  >
                    <Copy className="h-3 w-3" />
                    {copiedText === 'Nginx config' ? 'Copied!' : 'Copy'}
                  </Button>
                </div>
                
                <Alert>
                  <Server className="h-4 w-4" />
                  <AlertDescription>
                    Server-level configuration requires VPS/dedicated server access. Not applicable for platforms like Vercel or Netlify.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RateLimitingGuide;