import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShoppingBag, Settings, Truck, DollarSign, CheckCircle } from 'lucide-react';

interface ShopifyStore {
  id: string;
  name: string;
  url: string;
  connected: boolean;
  products: number;
  orders: number;
}

const ShopifyIntegration: React.FC = () => {
  const [stores, setStores] = useState<ShopifyStore[]>([
    {
      id: '1',
      name: 'DroneHub Store',
      url: 'dronehub.myshopify.com',
      connected: true,
      products: 156,
      orders: 89
    }
  ]);
  
  const [newStoreUrl, setNewStoreUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [dropshipping, setDropshipping] = useState(true);

  const connectStore = () => {
    if (newStoreUrl && apiKey) {
      const newStore: ShopifyStore = {
        id: Date.now().toString(),
        name: newStoreUrl.replace('.myshopify.com', ''),
        url: newStoreUrl,
        connected: true,
        products: 0,
        orders: 0
      };
      setStores([...stores, newStore]);
      setNewStoreUrl('');
      setApiKey('');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5" />
            Shopify Store Integration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="stores">
            <TabsList>
              <TabsTrigger value="stores">Connected Stores</TabsTrigger>
              <TabsTrigger value="connect">Connect New Store</TabsTrigger>
              <TabsTrigger value="settings">Dropship Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="stores" className="space-y-4">
              {stores.map((store) => (
                <Card key={store.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{store.name}</h3>
                        <p className="text-sm text-gray-600">{store.url}</p>
                        <div className="flex gap-4 mt-2">
                          <span className="text-sm">Products: {store.products}</span>
                          <span className="text-sm">Orders: {store.orders}</span>
                        </div>
                      </div>
                      <Badge variant={store.connected ? "default" : "secondary"}>
                        {store.connected ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
            
            <TabsContent value="connect" className="space-y-4">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="store-url">Shopify Store URL</Label>
                  <Input
                    id="store-url"
                    placeholder="yourstore.myshopify.com"
                    value={newStoreUrl}
                    onChange={(e) => setNewStoreUrl(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="api-key">API Key</Label>
                  <Input
                    id="api-key"
                    type="password"
                    placeholder="Enter your Shopify API key"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                </div>
                <Button onClick={connectStore} className="w-full">
                  Connect Store
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="settings" className="space-y-4">
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium flex items-center gap-2">
                        <Truck className="h-4 w-4" />
                        Enable Dropshipping
                      </h4>
                      <p className="text-sm text-gray-600">Suppliers ship directly to customers</p>
                    </div>
                    <Switch checked={dropshipping} onCheckedChange={setDropshipping} />
                  </div>
                  
                  {dropshipping && (
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-green-700 mb-2">
                        <CheckCircle className="h-4 w-4" />
                        <span className="font-medium">Dropshipping Enabled</span>
                      </div>
                      <ul className="text-sm text-green-600 space-y-1">
                        <li>• Orders automatically forwarded to suppliers</li>
                        <li>• Suppliers handle shipping and fulfillment</li>
                        <li>• You earn commission on each sale</li>
                        <li>• No inventory management required</li>
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ShopifyIntegration;