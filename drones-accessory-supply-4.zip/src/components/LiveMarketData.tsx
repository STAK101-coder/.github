import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity, DollarSign, Users, Package } from "lucide-react";
import { useState, useEffect } from "react";

const marketData = [
  { name: "Tactical Drones", price: "$1,299", change: "+5.2%", trend: "up", volume: "847" },
  { name: "Surveillance Equipment", price: "$899", change: "-2.1%", trend: "down", volume: "423" },
  { name: "Combat Accessories", price: "$299", change: "+8.7%", trend: "up", volume: "1,234" },
  { name: "Stealth Technology", price: "$2,499", change: "+12.3%", trend: "up", volume: "156" }
];

export default function LiveMarketData() {
  const [liveStats, setLiveStats] = useState({
    totalSales: 2847,
    activeUsers: 1234,
    ordersToday: 89,
    revenue: 45670
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveStats(prev => ({
        totalSales: prev.totalSales + Math.floor(Math.random() * 3),
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 5) - 2,
        ordersToday: prev.ordersToday + Math.floor(Math.random() * 2),
        revenue: prev.revenue + Math.floor(Math.random() * 500)
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Total Sales</p>
                <p className="text-2xl font-bold">{liveStats.totalSales.toLocaleString()}</p>
              </div>
              <Package className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-600 to-green-800 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Active Users</p>
                <p className="text-2xl font-bold">{liveStats.activeUsers.toLocaleString()}</p>
              </div>
              <Users className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-600 to-purple-800 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Orders Today</p>
                <p className="text-2xl font-bold">{liveStats.ordersToday}</p>
              </div>
              <Activity className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-red-600 to-red-800 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Revenue</p>
                <p className="text-2xl font-bold">${liveStats.revenue.toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Live Market Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {marketData.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${item.trend === 'up' ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                  <span className="text-white font-medium">{item.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-gray-300">{item.price}</span>
                  <div className="flex items-center gap-1">
                    {item.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                    <Badge variant={item.trend === 'up' ? 'default' : 'destructive'}>
                      {item.change}
                    </Badge>
                  </div>
                  <span className="text-sm text-gray-400">Vol: {item.volume}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}