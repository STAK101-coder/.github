import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Activity, Zap } from 'lucide-react';

const AIAnalytics = () => {
  const metrics = [
    {
      title: 'Tasks Completed Today',
      value: 47,
      target: 50,
      trend: 'up',
      change: '+12%'
    },
    {
      title: 'Automation Efficiency',
      value: 94,
      target: 95,
      trend: 'up',
      change: '+3%'
    },
    {
      title: 'Cost Savings',
      value: 78,
      target: 80,
      trend: 'down',
      change: '-2%'
    },
    {
      title: 'Response Time',
      value: 92,
      target: 90,
      trend: 'up',
      change: '+5%'
    }
  ];

  const recentActions = [
    {
      action: 'Updated 15 product prices based on competitor analysis',
      time: '2 minutes ago',
      type: 'pricing'
    },
    {
      action: 'Processed 8 new orders and sent confirmations',
      time: '5 minutes ago',
      type: 'orders'
    },
    {
      action: 'Restocked 3 low inventory items from suppliers',
      time: '12 minutes ago',
      type: 'inventory'
    },
    {
      action: 'Generated performance report for marketing team',
      time: '25 minutes ago',
      type: 'analytics'
    },
    {
      action: 'Optimized ad campaign budgets across platforms',
      time: '1 hour ago',
      type: 'marketing'
    }
  ];

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'pricing': return <TrendingUp className="h-4 w-4" />;
      case 'orders': return <Activity className="h-4 w-4" />;
      case 'inventory': return <Zap className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getActionColor = (type: string) => {
    switch (type) {
      case 'pricing': return 'bg-green-100 text-green-800';
      case 'orders': return 'bg-blue-100 text-blue-800';
      case 'inventory': return 'bg-yellow-100 text-yellow-800';
      case 'analytics': return 'bg-purple-100 text-purple-800';
      case 'marketing': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-muted-foreground">
                  {metric.title}
                </p>
                <Badge variant={metric.trend === 'up' ? 'default' : 'secondary'}>
                  {metric.trend === 'up' ? (
                    <TrendingUp className="h-3 w-3 mr-1" />
                  ) : (
                    <TrendingDown className="h-3 w-3 mr-1" />
                  )}
                  {metric.change}
                </Badge>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold">{metric.value}</span>
                  <span className="text-sm text-muted-foreground">/{metric.target}</span>
                </div>
                <Progress value={(metric.value / metric.target) * 100} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent AI Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentActions.map((action, index) => (
              <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                <div className={`p-2 rounded-full ${getActionColor(action.type)}`}>
                  {getActionIcon(action.type)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{action.action}</p>
                  <p className="text-xs text-muted-foreground">{action.time}</p>
                </div>
                <Badge className={getActionColor(action.type)}>
                  {action.type}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AIAnalytics;