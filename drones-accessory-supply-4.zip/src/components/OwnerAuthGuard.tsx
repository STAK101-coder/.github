import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Lock, Eye, EyeOff } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface OwnerAuthGuardProps {
  onAuthenticated: () => void;
}

const OwnerAuthGuard: React.FC<OwnerAuthGuardProps> = ({ onAuthenticated }) => {
  const [credentials, setCredentials] = useState({ username: '', password: '', ownerKey: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const OWNER_CREDENTIALS = {
    username: 'droneowner',
    password: 'DroneWars2024!',
    ownerKey: 'DW-OWNER-2024-SECURE'
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    await new Promise(resolve => setTimeout(resolve, 1000));

    if (
      credentials.username === OWNER_CREDENTIALS.username &&
      credentials.password === OWNER_CREDENTIALS.password &&
      credentials.ownerKey === OWNER_CREDENTIALS.ownerKey
    ) {
      sessionStorage.setItem('owner_authenticated', 'true');
      sessionStorage.setItem('owner_session', Date.now().toString());
      onAuthenticated();
    } else {
      setError('Invalid credentials. Access denied.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-slate-700 bg-slate-800/50 backdrop-blur">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-red-600/20 rounded-full">
              <Shield className="h-8 w-8 text-red-400" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white">OWNER ACCESS</CardTitle>
          <p className="text-slate-400">Secure Platform Management</p>
          <Badge variant="destructive" className="mt-2">CLASSIFIED ACCESS</Badge>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-slate-300">Username</Label>
              <Input
                id="username"
                type="text"
                value={credentials.username}
                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="Enter owner username"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-300">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={credentials.password}
                  onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                  className="bg-slate-700 border-slate-600 text-white pr-10"
                  placeholder="Enter secure password"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 text-slate-400 hover:text-white"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ownerKey" className="text-slate-300">Owner Key</Label>
              <Input
                id="ownerKey"
                type="password"
                value={credentials.ownerKey}
                onChange={(e) => setCredentials({...credentials, ownerKey: e.target.value})}
                className="bg-slate-700 border-slate-600 text-white"
                placeholder="Enter master owner key"
                required
              />
            </div>
            {error && (
              <div className="p-3 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">
                <Lock className="h-4 w-4 inline mr-2" />
                {error}
              </div>
            )}
            <Button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-700 text-white"
              disabled={loading}
            >
              {loading ? 'Authenticating...' : 'ACCESS OWNER DASHBOARD'}
            </Button>
          </form>
          <div className="mt-6 p-3 bg-slate-700/50 rounded text-xs text-slate-400">
            <p className="font-semibold mb-1">🔒 Security Notice:</p>
            <p>This is a restricted area. All access attempts are logged and monitored.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OwnerAuthGuard;