import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertTriangle, XCircle, Shield, Database, Code, Users, Zap } from 'lucide-react';

interface ReadinessItem {
  category: string;
  status: 'ready' | 'warning' | 'critical';
  items: { name: string; status: 'ready' | 'warning' | 'critical'; details: string }[];
}

const PlatformReadinessReport: React.FC = () => {
  const readinessData: ReadinessItem[] = [
    {
      category: 'Technical Infrastructure',
      status: 'ready',
      items: [
        { name: 'React/TypeScript Setup', status: 'ready', details: 'Modern stack with proper typing' },
        { name: 'Supabase Backend', status: 'ready', details: 'Database & auth configured' },
        { name: 'UI Components', status: 'ready', details: 'Complete shadcn/ui library' },
        { name: 'Responsive Design', status: 'ready', details: 'Mobile-first approach' }
      ]
    },
    {
      category: 'Business Features',
      status: 'ready',
      items: [
        { name: 'Product Catalog', status: 'ready', details: 'Drone inventory system' },
        { name: 'Supplier Management', status: 'ready', details: 'Verified suppliers database' },
        { name: 'Affiliate Programs', status: 'ready', details: 'Commission tracking system' },
        { name: 'Order Processing', status: 'ready', details: 'Complete checkout flow' }
      ]
    },
    {
      category: 'Security & Compliance',
      status: 'warning',
      items: [
        { name: 'Data Protection', status: 'ready', details: 'GDPR compliance features' },
        { name: 'Payment Security', status: 'warning', details: 'Needs SSL certificate' },
        { name: 'User Authentication', status: 'ready', details: 'Supabase auth system' },
        { name: 'API Security', status: 'warning', details: 'Rate limiting needed' }
      ]
    },
    {
      category: 'Customer Experience',
      status: 'ready',
      items: [
        { name: 'User Interface', status: 'ready', details: 'Professional design' },
        { name: 'Search & Filter', status: 'ready', details: 'Advanced product search' },
        { name: 'Mobile Experience', status: 'ready', details: 'Responsive layout' },
        { name: 'Performance', status: 'ready', details: 'Optimized loading' }
      ]
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'critical': return <XCircle className="h-5 w-5 text-red-500" />;
      default: return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      ready: 'bg-green-100 text-green-800',
      warning: 'bg-yellow-100 text-yellow-800',
      critical: 'bg-red-100 text-red-800'
    };
    return <Badge className={variants[status as keyof typeof variants]}>{status.toUpperCase()}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">Platform Readiness Analysis</h1>
        <div className="flex justify-center items-center space-x-4">
          <Shield className="h-8 w-8 text-blue-500" />
          <span className="text-xl font-semibold">Production Ready: 85%</span>
        </div>
      </div>

      <div className="grid gap-6">
        {readinessData.map((category, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{category.category}</span>
                {getStatusBadge(category.status)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {category.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(item.status)}
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-600">{item.details}</p>
                      </div>
                    </div>
                    {getStatusBadge(item.status)}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PlatformReadinessReport;