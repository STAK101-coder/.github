import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Camera, Gamepad2, Wrench, Zap } from 'lucide-react';

const categories = [
  {
    icon: Camera,
    title: 'Camera Drones',
    description: 'Professional photography & videography',
    color: 'from-blue-500 to-cyan-500',
    count: '120+ models'
  },
  {
    icon: Gamepad2,
    title: 'Racing Drones',
    description: 'High-speed FPV racing machines',
    color: 'from-red-500 to-orange-500',
    count: '85+ models'
  },
  {
    icon: Wrench,
    title: 'Accessories',
    description: 'Parts, batteries & upgrades',
    color: 'from-green-500 to-emerald-500',
    count: '500+ items'
  },
  {
    icon: Zap,
    title: 'Commercial',
    description: 'Industrial & enterprise solutions',
    color: 'from-purple-500 to-pink-500',
    count: '45+ models'
  }
];

const CategorySection: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Explore Our <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Categories</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Find the perfect drone for your needs, from hobbyist to professional
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-gradient-to-br from-white to-gray-50 hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className={`inline-flex p-4 rounded-full bg-gradient-to-r ${category.color} mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{category.title}</h3>
                  <p className="text-gray-600 mb-3">{category.description}</p>
                  <div className="text-sm font-semibold text-blue-600">{category.count}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;