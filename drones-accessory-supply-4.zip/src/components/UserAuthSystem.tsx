import React, { useState } from 'react';
import AuthForm from './AuthForm';
import EmailVerification from './EmailVerification';
import { useToast } from '../hooks/use-toast';

interface User {
  id: string;
  username: string;
  email: string;
  phone: string;
  verified: boolean;
  createdAt: Date;
}

interface UserAuthSystemProps {
  onAuthComplete: (user: User) => void;
}

const UserAuthSystem: React.FC<UserAuthSystemProps> = ({ onAuthComplete }) => {
  const [authStep, setAuthStep] = useState<'auth' | 'verification' | 'complete'>('auth');
  const [pendingUser, setPendingUser] = useState<Partial<User> | null>(null);
  const { toast } = useToast();

  const handleAuthSuccess = (userData: any) => {
    if (userData.needsVerification) {
      // User just signed up, needs email verification
      setPendingUser({
        id: userData.id || 'temp-id',
        username: userData.username,
        email: userData.email,
        phone: userData.phone,
        verified: false,
        createdAt: new Date()
      });
      setAuthStep('verification');
      toast({
        title: 'Account Created!',
        description: 'Please verify your email to complete registration.'
      });
    } else {
      // User signed in with existing verified account
      const user: User = {
        id: userData.id || 'user-' + Date.now(),
        username: userData.username || userData.email.split('@')[0],
        email: userData.email,
        phone: userData.phone || '',
        verified: true,
        createdAt: userData.createdAt || new Date()
      };
      onAuthComplete(user);
    }
  };

  const handleVerificationSuccess = () => {
    if (pendingUser) {
      const verifiedUser: User = {
        ...pendingUser,
        verified: true
      } as User;
      
      toast({
        title: 'Welcome to Drone Wars!',
        description: 'Your account has been verified successfully.'
      });
      
      onAuthComplete(verifiedUser);
    }
  };

  const handleResendEmail = () => {
    toast({
      title: 'Verification Email Sent',
      description: 'A new verification code has been sent to your email.'
    });
  };

  if (authStep === 'verification' && pendingUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center p-4">
        <EmailVerification
          email={pendingUser.email!}
          onVerificationSuccess={handleVerificationSuccess}
          onResendEmail={handleResendEmail}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center p-4">
      <AuthForm onAuthSuccess={handleAuthSuccess} />
    </div>
  );
};

export default UserAuthSystem;
export type { User };