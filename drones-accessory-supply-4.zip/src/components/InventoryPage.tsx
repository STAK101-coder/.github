import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface Supplier {
  id: string;
  name: string;
  email: string;
  commission_rate: number;
  status: string;
}

interface InventoryItem {
  id: string;
  name: string;
  price: number;
  stock_quantity: number;
  category: string;
  supplier_id: string;
  suppliers?: Supplier;
}

const InventoryPage: React.FC = () => {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: suppliersData } = await supabase
        .from('suppliers')
        .select('*');
      
      const { data: inventoryData } = await supabase
        .from('inventory')
        .select('*, suppliers(*)');
      
      setSuppliers(suppliersData || []);
      setInventory(inventoryData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Supplier Inventory</h1>
        <p className="text-gray-600">Manage products from affiliate suppliers</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Suppliers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {suppliers.map((supplier) => (
                <div key={supplier.id} className="flex justify-between items-center p-2 border rounded">
                  <div>
                    <div className="font-medium">{supplier.name}</div>
                    <div className="text-sm text-gray-500">{supplier.commission_rate}% commission</div>
                  </div>
                  <Badge variant={supplier.status === 'active' ? 'default' : 'secondary'}>
                    {supplier.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Inventory Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {inventory.map((item) => (
                <div key={item.id} className="flex justify-between items-center p-3 border rounded">
                  <div>
                    <div className="font-medium">{item.name}</div>
                    <div className="text-sm text-gray-500">
                      {item.suppliers?.name} • {item.category}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">${item.price}</div>
                    <div className="text-sm text-gray-500">{item.stock_quantity} in stock</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InventoryPage;