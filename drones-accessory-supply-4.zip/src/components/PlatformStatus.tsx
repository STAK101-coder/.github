import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { CheckCircle, AlertCircle, Clock, Globe } from 'lucide-react';

const PlatformStatus = () => {
  const statusItems = [
    { name: 'Frontend Build', status: 'complete', progress: 100 },
    { name: 'Backend Integration', status: 'complete', progress: 100 },
    { name: 'Database Setup', status: 'complete', progress: 100 },
    { name: 'UI Components', status: 'complete', progress: 100 },
    { name: 'Security Features', status: 'pending', progress: 75 },
    { name: 'SSL Certificate', status: 'pending', progress: 0 },
    { name: 'Domain Setup', status: 'pending', progress: 0 }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'complete':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'complete':
        return <Badge variant="default" className="bg-green-500">Ready</Badge>;
      case 'pending':
        return <Badge variant="secondary">Setup Required</Badge>;
      default:
        return <Badge variant="destructive">Error</Badge>;
    }
  };

  const overallProgress = Math.round(
    statusItems.reduce((sum, item) => sum + item.progress, 0) / statusItems.length
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Platform Status
          </CardTitle>
          <CardDescription>
            Your drone dropshipping platform is {overallProgress}% ready for deployment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm text-muted-foreground">{overallProgress}%</span>
              </div>
              <Progress value={overallProgress} className="h-2" />
            </div>
            
            <div className="space-y-3">
              {statusItems.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(item.status)}
                    <span className="font-medium">{item.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">{item.progress}%</span>
                    {getStatusBadge(item.status)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Next Steps</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm">✅ Your platform is ready for testing locally</p>
            <p className="text-sm">⚠️ Complete SSL setup for production deployment</p>
            <p className="text-sm">🚀 Deploy to get your platform online</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PlatformStatus;