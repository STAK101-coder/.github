import React, { createContext, useContext, useState } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  category: string;
  features: string[];
  inStock: boolean;
  images: string[];
}

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  products: Product[];
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;
}

const defaultAppContext: AppContextType = {
  sidebarOpen: false,
  toggleSidebar: () => {},
  products: [],
  selectedProduct: null,
  setSelectedProduct: () => {},
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

const sampleProducts: Product[] = [
  {
    id: '1',
    name: 'DJI Mini 3 Pro',
    price: 759,
    originalPrice: 899,
    rating: 4.8,
    reviews: 1250,
    image: '🚁',
    category: 'Camera Drones',
    features: ['4K HDR Video', '34min Flight Time', 'Obstacle Sensing'],
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1508614589041-895b88991e3e?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?w=400&h=400&fit=crop'
    ]
  },
  {
    id: '2',
    name: 'Autel EVO Lite+',
    price: 1299,
    rating: 4.6,
    reviews: 890,
    image: '🚁',
    category: 'Professional',
    features: ['6K Video', '40min Flight', 'RYYB Sensor'],
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=400&fit=crop'
    ]
  }
];

export const AppContextProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const toggleSidebar = () => {
    setSidebarOpen(prev => !prev);
  };

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        products: sampleProducts,
        selectedProduct,
        setSelectedProduct,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export type { Product };